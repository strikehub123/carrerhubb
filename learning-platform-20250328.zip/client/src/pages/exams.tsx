import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Exam, Category } from "@/lib/types";
import ExamCard from "@/components/exam/ExamCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Filter, X } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const Exams = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);

  // Fetch exams and categories
  const { data: exams, isLoading: isLoadingExams } = useQuery({
    queryKey: ['/api/exams'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const { data: categories, isLoading: isLoadingCategories } = useQuery({
    queryKey: ['/api/categories'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Apply filters to exams
  const filteredExams = exams?.filter((exam: Exam) => {
    // Filter by search query
    const matchesSearch = exam.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         exam.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Filter by category
    const matchesCategory = selectedCategory === "all" || exam.categoryId.toString() === selectedCategory;
    
    // Filter by difficulty
    const matchesDifficulty = selectedDifficulty === "all" || exam.difficulty === selectedDifficulty;
    
    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  const toggleFilters = () => {
    setIsFiltersOpen(!isFiltersOpen);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Apply search filter
  };

  const resetFilters = () => {
    setSearchQuery("");
    setSelectedCategory("all");
    setSelectedDifficulty("all");
  };

  const isLoading = isLoadingExams || isLoadingCategories;

  return (
    <div className="bg-neutral-100 py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
          <h1 className="text-2xl md:text-3xl font-bold mb-4 md:mb-0">Practice Exams</h1>
          
          <div className="flex items-center">
            <form onSubmit={handleSearch} className="relative flex-grow mr-2">
              <Input
                type="text"
                placeholder="Search exams..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
              />
              <button
                type="submit"
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-neutral-400"
              >
                <Search size={18} />
              </button>
            </form>
            
            <Button
              variant="outline"
              size="icon"
              onClick={toggleFilters}
              className="md:hidden"
            >
              <Filter size={18} />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mb-8">
          {/* Filters - Desktop */}
          <div className="hidden md:block bg-white rounded-lg shadow-sm p-6">
            <div className="mb-6">
              <h2 className="font-semibold mb-3">Categories</h2>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="category-all"
                    name="category"
                    value="all"
                    checked={selectedCategory === "all"}
                    onChange={() => setSelectedCategory("all")}
                    className="mr-2"
                  />
                  <label htmlFor="category-all">All Categories</label>
                </div>
                
                {categories?.map((category: Category) => (
                  <div key={category.id} className="flex items-center">
                    <input
                      type="radio"
                      id={`category-${category.id}`}
                      name="category"
                      value={category.id.toString()}
                      checked={selectedCategory === category.id.toString()}
                      onChange={() => setSelectedCategory(category.id.toString())}
                      className="mr-2"
                    />
                    <label htmlFor={`category-${category.id}`}>{category.name}</label>
                  </div>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <h2 className="font-semibold mb-3">Difficulty</h2>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="difficulty-all"
                    name="difficulty"
                    value="all"
                    checked={selectedDifficulty === "all"}
                    onChange={() => setSelectedDifficulty("all")}
                    className="mr-2"
                  />
                  <label htmlFor="difficulty-all">All Levels</label>
                </div>
                
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="difficulty-beginner"
                    name="difficulty"
                    value="Beginner-Friendly"
                    checked={selectedDifficulty === "Beginner-Friendly"}
                    onChange={() => setSelectedDifficulty("Beginner-Friendly")}
                    className="mr-2"
                  />
                  <label htmlFor="difficulty-beginner">Beginner</label>
                </div>
                
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="difficulty-intermediate"
                    name="difficulty"
                    value="Intermediate"
                    checked={selectedDifficulty === "Intermediate"}
                    onChange={() => setSelectedDifficulty("Intermediate")}
                    className="mr-2"
                  />
                  <label htmlFor="difficulty-intermediate">Intermediate</label>
                </div>
                
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="difficulty-advanced"
                    name="difficulty"
                    value="Advanced"
                    checked={selectedDifficulty === "Advanced"}
                    onChange={() => setSelectedDifficulty("Advanced")}
                    className="mr-2"
                  />
                  <label htmlFor="difficulty-advanced">Advanced</label>
                </div>
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full"
              onClick={resetFilters}
            >
              Reset Filters
            </Button>
          </div>

          {/* Filters - Mobile */}
          {isFiltersOpen && (
            <div className="md:hidden fixed inset-0 bg-black/50 z-50 flex justify-end">
              <div className="bg-white h-full w-4/5 overflow-auto p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="font-bold text-lg">Filters</h2>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={toggleFilters}
                  >
                    <X size={20} />
                  </Button>
                </div>
                
                <div className="mb-6">
                  <h3 className="font-semibold mb-3">Categories</h3>
                  <Select
                    value={selectedCategory}
                    onValueChange={setSelectedCategory}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {categories?.map((category: Category) => (
                        <SelectItem key={category.id} value={category.id.toString()}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="mb-6">
                  <h3 className="font-semibold mb-3">Difficulty</h3>
                  <Select
                    value={selectedDifficulty}
                    onValueChange={setSelectedDifficulty}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select Difficulty" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="Beginner-Friendly">Beginner</SelectItem>
                      <SelectItem value="Intermediate">Intermediate</SelectItem>
                      <SelectItem value="Advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex flex-col space-y-3">
                  <Button onClick={resetFilters} variant="outline">
                    Reset Filters
                  </Button>
                  <Button onClick={toggleFilters}>
                    Apply Filters
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Exams Grid */}
          <div className="lg:col-span-3">
            {isLoading ? (
              // Loading state
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="border border-neutral-200 rounded-lg p-6 animate-pulse">
                    <div className="flex justify-between items-start mb-4">
                      <div className="h-5 w-32 bg-neutral-200 rounded"></div>
                      <div className="h-5 w-24 bg-neutral-200 rounded"></div>
                    </div>
                    <div className="h-6 bg-neutral-200 rounded mb-2"></div>
                    <div className="h-4 bg-neutral-200 rounded mb-2"></div>
                    <div className="h-4 bg-neutral-200 rounded w-3/4 mb-4"></div>
                    <div className="flex items-center mb-6">
                      <div className="h-4 w-24 bg-neutral-200 rounded mr-4"></div>
                      <div className="h-4 w-24 bg-neutral-200 rounded"></div>
                    </div>
                    <div className="h-4 w-full bg-neutral-200 rounded"></div>
                  </div>
                ))}
              </div>
            ) : filteredExams?.length > 0 ? (
              // Exams found
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredExams.map((exam: Exam) => (
                  <ExamCard key={exam.id} exam={exam} />
                ))}
              </div>
            ) : (
              // No exams found
              <div className="bg-white p-8 rounded-lg shadow-sm text-center">
                <h3 className="font-semibold text-lg mb-2">No exams found</h3>
                <p className="text-neutral-600 mb-4">
                  We couldn't find any exams matching your search criteria.
                </p>
                <Button onClick={resetFilters}>Clear Filters</Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Exams;
