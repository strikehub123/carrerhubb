import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { useQuery } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Course } from '@/shared/schema';
import { useLocation } from 'wouter';

// Payment method schema
const paymentSchema = z.object({
  cardNumber: z.string().min(16, "Card number must be 16 digits").max(16),
  cardHolder: z.string().min(3, "Cardholder name is required"),
  expiryMonth: z.string().min(2, "Month is required"),
  expiryYear: z.string().min(2, "Year is required"),
  cvv: z.string().min(3, "CVV must be 3 digits").max(3),
  paymentMethod: z.enum(["credit", "debit", "upi", "netbanking"]),
  upiId: z.string().optional(),
  bankName: z.string().optional(),
});

// Format price function
const formatPrice = (price: number) => {
  return `₹${price.toLocaleString('en-IN')}`;
};

type PaymentFormValues = z.infer<typeof paymentSchema>;

export default function PurchasePage() {
  const [location, setLocation] = useLocation();
  const courseId = Number(location.split('/').pop());
  const { user } = useAuth();
  const { toast } = useToast();

  
  // Get course details
  const { data: course, isLoading } = useQuery({
    queryKey: ['/api/courses', courseId],
    queryFn: () => apiRequest<Course>(`/api/courses/${courseId}`),
    enabled: !!courseId && !isNaN(courseId),
  });
  
  // Payment form
  const form = useForm<PaymentFormValues>({
    resolver: zodResolver(paymentSchema),
    defaultValues: {
      cardNumber: "",
      cardHolder: "",
      expiryMonth: "",
      expiryYear: "",
      cvv: "",
      paymentMethod: "credit",
      upiId: "",
      bankName: "",
    },
    mode: "onChange",
  });
  
  const paymentMethod = form.watch("paymentMethod");
  
  const onSubmit = async (data: PaymentFormValues) => {
    try {
      // In a real app, this would make a payment API request
      console.log("Payment data:", data);
      
      // Simulating a payment request
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Create user progress entry for this course
      if (user && course) {
        try {
          await apiRequest('/api/users/' + user.id + '/progress', {
            method: 'POST',
            body: JSON.stringify({
              userId: user.id,
              courseId: course.id,
              completedLessons: 0,
            }),
          });
          
          // Invalidate progress list cache
          queryClient.invalidateQueries({ queryKey: ['/api/users', user.id, 'progress'] });
          
          toast({
            title: "Course purchased successfully!",
            description: `You now have access to "${course.title}"`,
          });
          
          // Redirect to course page
          setLocation(`/courses/${course.id}`);
        } catch (error) {
          console.error("Failed to enroll in course:", error);
          toast({
            title: "Error",
            description: "Failed to enroll in the course. Please try again.",
            variant: "destructive",
          });
        }
      }
    } catch (error) {
      console.error("Payment error:", error);
      toast({
        title: "Payment failed",
        description: "There was an error processing your payment. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  if (isLoading) {
    return (
      <div className="container mx-auto py-8 px-4">
        <Card className="w-full max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-center">Loading...</CardTitle>
          </CardHeader>
        </Card>
      </div>
    );
  }
  
  if (!course) {
    return (
      <div className="container mx-auto py-8 px-4">
        <Card className="w-full max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-center">Course Not Found</CardTitle>
            <CardDescription className="text-center">
              The course you're looking for doesn't exist or has been removed.
            </CardDescription>
          </CardHeader>
          <CardFooter className="flex justify-center">
            <Button onClick={() => setLocation('/courses')}>Browse Courses</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  if (!user) {
    return (
      <div className="container mx-auto py-8 px-4">
        <Card className="w-full max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-center">Login Required</CardTitle>
            <CardDescription className="text-center">
              Please login to purchase this course.
            </CardDescription>
          </CardHeader>
          <CardFooter className="flex justify-center gap-4">
            <Button onClick={() => setLocation('/login')} variant="outline">Login</Button>
            <Button onClick={() => setLocation('/register')}>Create Account</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-8 text-center">Purchase Course</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-[1fr_400px] gap-8 max-w-6xl mx-auto">
        {/* Course Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Order Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-lg overflow-hidden">
              <img 
                src={course.imageUrl || "https://images.unsplash.com/photo-1516321318423-f06f85e504b3"} 
                alt={course.title} 
                className="w-full h-48 object-cover"
              />
            </div>
            
            <div className="space-y-2">
              <h2 className="text-xl font-semibold">{course.title}</h2>
              <p className="text-muted-foreground">{course.description}</p>
              
              <div className="flex justify-between pt-4 border-t">
                <span className="font-medium">Difficulty:</span>
                <span>{course.difficulty}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="font-medium">Duration:</span>
                <span>{Math.floor(course.duration / 60)} hours {course.duration % 60} minutes</span>
              </div>
              
              <div className="flex justify-between">
                <span className="font-medium">Rating:</span>
                <span>{course.rating} ⭐ ({course.ratingCount} reviews)</span>
              </div>
              
              <div className="flex justify-between text-lg font-bold pt-4 border-t">
                <span>Price:</span>
                <span className="text-primary">{formatPrice(course.price)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Payment Form */}
        <Card>
          <CardHeader>
            <CardTitle>Payment Details</CardTitle>
            <CardDescription>
              Complete your purchase securely
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="paymentMethod"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel>Payment Method</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex flex-col space-y-1"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="credit" id="credit" />
                            <Label htmlFor="credit">Credit Card</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="debit" id="debit" />
                            <Label htmlFor="debit">Debit Card</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="upi" id="upi" />
                            <Label htmlFor="upi">UPI Payment</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="netbanking" id="netbanking" />
                            <Label htmlFor="netbanking">Net Banking</Label>
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {(paymentMethod === "credit" || paymentMethod === "debit") && (
                  <>
                    <FormField
                      control={form.control}
                      name="cardNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Card Number</FormLabel>
                          <FormControl>
                            <Input placeholder="1234 5678 9012 3456" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="cardHolder"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Cardholder Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name="expiryMonth"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Month</FormLabel>
                            <FormControl>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <SelectTrigger>
                                  <SelectValue placeholder="MM" />
                                </SelectTrigger>
                                <SelectContent>
                                  {Array.from({ length: 12 }, (_, i) => {
                                    const month = (i + 1).toString().padStart(2, '0');
                                    return (
                                      <SelectItem key={month} value={month}>
                                        {month}
                                      </SelectItem>
                                    );
                                  })}
                                </SelectContent>
                              </Select>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="expiryYear"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Year</FormLabel>
                            <FormControl>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <SelectTrigger>
                                  <SelectValue placeholder="YY" />
                                </SelectTrigger>
                                <SelectContent>
                                  {Array.from({ length: 10 }, (_, i) => {
                                    const year = (new Date().getFullYear() + i).toString().slice(-2);
                                    return (
                                      <SelectItem key={year} value={year}>
                                        {year}
                                      </SelectItem>
                                    );
                                  })}
                                </SelectContent>
                              </Select>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="cvv"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>CVV</FormLabel>
                            <FormControl>
                              <Input placeholder="123" maxLength={3} {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </>
                )}
                
                {paymentMethod === "upi" && (
                  <FormField
                    control={form.control}
                    name="upiId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>UPI ID</FormLabel>
                        <FormControl>
                          <Input placeholder="yourname@upi" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
                
                {paymentMethod === "netbanking" && (
                  <FormField
                    control={form.control}
                    name="bankName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Select Bank</FormLabel>
                        <FormControl>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select your bank" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="sbi">State Bank of India</SelectItem>
                              <SelectItem value="hdfc">HDFC Bank</SelectItem>
                              <SelectItem value="icici">ICICI Bank</SelectItem>
                              <SelectItem value="axis">Axis Bank</SelectItem>
                              <SelectItem value="kotak">Kotak Mahindra Bank</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
                
                <div className="pt-4">
                  <Button type="submit" className="w-full" disabled={form.formState.isSubmitting}>
                    {form.formState.isSubmitting 
                      ? "Processing..." 
                      : `Pay ${formatPrice(course.price)}`}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-xs text-muted-foreground">
              Your payment information is encrypted and secure.
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}