import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import ExamInterfaceComponent from "@/components/exam/ExamInterface";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

const ExamInterface = () => {
  const { id } = useParams<{ id: string }>();
  const examId = parseInt(id);
  const [location] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Extract paper ID from URL query params if present
  const [paperId, setPaperId] = useState<number>(0);
  
  useEffect(() => {
    const searchParams = new URLSearchParams(location.split('?')[1]);
    const paperParam = searchParams.get('paper');
    if (paperParam) {
      const parsedPaperId = parseInt(paperParam);
      if (!isNaN(parsedPaperId)) {
        setPaperId(parsedPaperId);
      }
    }
  }, [location]);

  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to take this exam",
        variant: "destructive",
      });
      window.location.href = "/exams/" + examId;
    }
  }, [user, examId, toast]);

  // Fetch exam details
  const { data: exam, isLoading: isLoadingExam, error: examError } = useQuery({
    queryKey: [`/api/exams/${examId}`],
    enabled: !isNaN(examId) && !!user,
    staleTime: 0, // Always fetch fresh exam data
  });

  // Fetch exam questions for the specific paper
  const { data: questions, isLoading: isLoadingQuestions, error: questionsError } = useQuery({
    queryKey: [`/api/exams/${examId}/questions`, paperId],
    queryFn: async () => {
      const url = paperId > 0 
        ? `/api/exams/${examId}/questions?paper=${paperId}` 
        : `/api/exams/${examId}/questions`;
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Failed to fetch questions');
      }
      return response.json();
    },
    enabled: !isNaN(examId) && !!user && !!exam,
    staleTime: 0, // Always fetch fresh questions
  });

  const isLoading = isLoadingExam || isLoadingQuestions;
  const error = examError || questionsError;

  if (isNaN(examId)) {
    return (
      <div className="bg-neutral-100 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <h3 className="font-semibold text-lg mb-2">Invalid Exam ID</h3>
            <p className="text-neutral-600">
              The exam ID provided is invalid. Please try again with a valid ID.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="bg-neutral-100 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md overflow-hidden animate-pulse">
            <div className="border-b border-neutral-200 p-4 flex justify-between items-center">
              <div className="h-6 w-48 bg-neutral-200 rounded"></div>
              <div className="h-8 w-24 bg-neutral-200 rounded"></div>
            </div>
            
            <div className="p-6">
              <div className="h-6 w-64 bg-neutral-200 rounded mb-6"></div>
              <div className="h-8 w-full bg-neutral-200 rounded mb-4"></div>
              <div className="h-24 w-full bg-neutral-200 rounded mb-6"></div>
              
              <div className="space-y-3 mb-6">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="h-16 w-full bg-neutral-200 rounded"></div>
                ))}
              </div>
              
              <div className="flex justify-between">
                <div className="h-10 w-24 bg-neutral-200 rounded"></div>
                <div className="h-10 w-32 bg-neutral-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !exam || !questions) {
    return (
      <div className="bg-neutral-100 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <h3 className="font-semibold text-lg mb-2">Error Loading Exam</h3>
            <p className="text-neutral-600">
              There was a problem loading the exam. Please try again later.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-neutral-100 py-8">
      <div className="container mx-auto px-4">
        <ExamInterfaceComponent exam={exam} questions={questions} paperId={paperId} />
      </div>
    </div>
  );
};

export default ExamInterface;
