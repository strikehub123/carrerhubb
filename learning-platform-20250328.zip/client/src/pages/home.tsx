import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Hero from "@/components/home/Hero";
import FeaturedCategories from "@/components/home/FeaturedCategories";
import FeaturedCourses from "@/components/home/FeaturedCourses";
import ExamsSection from "@/components/home/ExamsSection";
import TopCompanies from "@/components/home/TopCompanies";
import { queryClient } from "@/lib/queryClient";

const Home = () => {
  // Prefetch categories, courses, and exams for smoother navigation
  useEffect(() => {
    queryClient.prefetchQuery({
      queryKey: ['/api/categories'],
      staleTime: 5 * 60 * 1000, // 5 minutes
    });
    
    queryClient.prefetchQuery({
      queryKey: ['/api/courses'],
      staleTime: 5 * 60 * 1000,
    });
    
    queryClient.prefetchQuery({
      queryKey: ['/api/exams'],
      staleTime: 5 * 60 * 1000,
    });
  }, []);

  return (
    <>
      <Hero />
      <TopCompanies />
      <FeaturedCategories />
      <FeaturedCourses />
      <ExamsSection />
    </>
  );
};

export default Home;
