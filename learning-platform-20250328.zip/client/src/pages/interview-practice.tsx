import { useState, useEffect, type ReactNode } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  Clock,
  ChevronLeft,
  ChevronRight,
  Flag,
  CheckCircle,
  List,
  HelpCircle,
  ArrowLeft,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Film,
  Camera,
  Monitor,
  Send,
  Code,
  User
} from "lucide-react";

import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { Textarea } from "../components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "../components/ui/dialog";
import { Separator } from "../components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "../components/ui/tooltip";

// Define question type for the application
type QuestionType = 'technical' | 'coding' | 'system-design' | 'behavioral';

// Define interview data interfaces
interface InterviewQuestion {
  id: number;
  type: QuestionType;
  question: string;
  hints: string[];
  answerGuidelines: string[];
  codeSnippet?: string;
}

interface InterviewData {
  id: number;
  title: string;
  company: string;
  totalQuestions: number;
  currentQuestionIndex: number;
  timeRemaining: number;
  questions: InterviewQuestion[];
}

// Mock interview practice data
const getInterviewData = (id: number): InterviewData => {
  return {
    id,
    title: "Technical Java Developer Interview",
    company: "Microsoft",
    totalQuestions: 5,
    currentQuestionIndex: 0,
    timeRemaining: 45 * 60, // 45 minutes in seconds
    questions: [
      {
        id: 1,
        type: "technical",
        question: "Can you explain the difference between HashMap and ConcurrentHashMap in Java?",
        hints: [
          "Think about thread safety",
          "Consider performance implications",
          "How does each handle concurrent modifications?"
        ],
        answerGuidelines: [
          "Discuss thread safety aspects of both implementations",
          "Explain the internal structure differences",
          "Mention performance considerations",
          "Describe use cases for each"
        ]
      },
      {
        id: 2,
        type: "coding",
        question: "Implement a function to check if a binary tree is balanced. A balanced tree is defined as a tree where the heights of the two subtrees of any node never differ by more than one.",
        codeSnippet: `class TreeNode {
  int val;
  TreeNode left;
  TreeNode right;
  
  TreeNode(int x) { val = x; }
}

public boolean isBalanced(TreeNode root) {
  // Your code here
}`,
        hints: [
          "Consider using a recursive approach",
          "Think about how to track height information efficiently",
          "Consider edge cases like null nodes"
        ],
        answerGuidelines: [
          "Implement a recursive solution",
          "Handle edge cases properly",
          "Time complexity should be O(n)",
          "Explain your thought process clearly"
        ]
      },
      {
        id: 3,
        type: "system-design",
        question: "Design a distributed logging system that can handle logs from thousands of services and allow efficient searching and alerting.",
        hints: [
          "Consider scalability requirements",
          "Think about data storage options",
          "How would you handle search functionality?",
          "Consider real-time alerting mechanisms"
        ],
        answerGuidelines: [
          "Present a clear architecture diagram",
          "Explain data flow through the system",
          "Discuss technology choices and tradeoffs",
          "Address scalability and reliability concerns"
        ]
      },
      {
        id: 4,
        type: "behavioral",
        question: "Tell me about a time when you had to deal with a significant technical challenge. How did you approach it, and what was the outcome?",
        hints: [
          "Use the STAR method (Situation, Task, Action, Result)",
          "Be specific about your personal contribution",
          "Highlight technical and soft skills used",
          "Discuss what you learned from the experience"
        ],
        answerGuidelines: [
          "Structure answer using STAR method",
          "Be specific with technical details",
          "Demonstrate problem-solving approach",
          "Highlight collaboration and communication skills",
          "Show outcome and lessons learned"
        ]
      },
      {
        id: 5,
        type: "technical",
        question: "Explain how garbage collection works in Java. What are the different types of garbage collectors and when would you choose one over another?",
        hints: [
          "Discuss the basics of garbage collection",
          "Mention different garbage collection algorithms",
          "Consider memory management implications",
          "Think about performance tuning options"
        ],
        answerGuidelines: [
          "Explain mark-and-sweep and other algorithms",
          "Discuss generational garbage collection",
          "Compare different garbage collectors (G1, CMS, ZGC)",
          "Address performance considerations and tuning options"
        ]
      }
    ]
  };
};

const formatTime = (seconds: number): string => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
};

// Type mapping for question types to visual elements
const questionTypeIcons: Record<QuestionType, ReactNode> = {
  technical: <HelpCircle className="h-5 w-5" />,
  coding: <Code className="h-5 w-5" />,
  "system-design": <Monitor className="h-5 w-5" />,
  behavioral: <User className="h-5 w-5" />
};

const questionTypeColors: Record<QuestionType, string> = {
  technical: "bg-blue-50 text-blue-700 border-blue-200",
  coding: "bg-purple-50 text-purple-700 border-purple-200",
  "system-design": "bg-green-50 text-green-700 border-green-200",
  behavioral: "bg-orange-50 text-orange-700 border-orange-200"
};

const InterviewPractice = () => {
  const [, params] = useRoute("/interviews/:id/practice");
  const interviewId = params?.id ? parseInt(params.id) : 1;
  
  // State for the interview
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answer, setAnswer] = useState("");
  const [timeRemaining, setTimeRemaining] = useState(45 * 60); // 45 minutes in seconds
  const [confirmExitOpen, setConfirmExitOpen] = useState(false);
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [isRecording, setIsRecording] = useState(false);
  const [showHints, setShowHints] = useState(false);
  const [endInterviewDialogOpen, setEndInterviewDialogOpen] = useState(false);
  
  // Fetch interview data
  const { data: interview, isLoading } = useQuery<InterviewData>({
    queryKey: [`/api/interviews/${interviewId}/practice`],
    queryFn: () => new Promise<InterviewData>((resolve) => {
      setTimeout(() => {
        resolve(getInterviewData(interviewId));
      }, 500);
    })
  });

  // Timer effect
  useEffect(() => {
    if (interview && timeRemaining > 0) {
      const timer = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            // Handle time up
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
      return () => clearInterval(timer);
    }
  }, [interview, timeRemaining]);

  // Handle next and previous question
  const goToNextQuestion = () => {
    if (interview && currentQuestionIndex < interview.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setAnswer("");
      setShowHints(false);
    }
  };

  const goToPreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
      setShowHints(false);
    }
  };

  // Toggle video/audio
  const toggleVideo = () => setVideoEnabled(!videoEnabled);
  const toggleAudio = () => setAudioEnabled(!audioEnabled);
  
  // Start/stop recording
  const toggleRecording = () => setIsRecording(!isRecording);
  
  // End interview
  const handleEndInterview = () => {
    setEndInterviewDialogOpen(true);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse">
          <div className="h-6 w-1/3 bg-gray-200 rounded mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="md:col-span-1">
              <div className="h-60 bg-gray-200 rounded mb-4"></div>
              <div className="h-20 bg-gray-200 rounded"></div>
            </div>
            <div className="md:col-span-3">
              <div className="h-12 bg-gray-200 rounded mb-4"></div>
              <div className="h-40 bg-gray-200 rounded mb-6"></div>
              <div className="h-60 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!interview) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-2xl font-bold mb-4">Interview not found</h1>
        <p className="mb-6">Sorry, the interview you're looking for doesn't exist or has been removed.</p>
        <Link href="/interviews">
          <Button>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Interviews
          </Button>
        </Link>
      </div>
    );
  }

  const currentQuestion = interview.questions[currentQuestionIndex];
  const questionProgress = ((currentQuestionIndex + 1) / interview.questions.length) * 100;
  const currentQuestionType = currentQuestion.type as QuestionType;
  const typeIcon = questionTypeIcons[currentQuestionType] || <HelpCircle className="h-5 w-5" />;
  const typeColor = questionTypeColors[currentQuestionType] || "bg-gray-50 text-gray-700 border-gray-200";

  return (
    <div className="container mx-auto px-4 py-6 max-w-screen-xl">
      {/* Header */}
      <div className="flex flex-wrap justify-between items-center mb-6">
        <div>
          <Link href={`/interviews/${interviewId}`} className="inline-flex items-center text-neutral-600 hover:text-primary mb-2">
            <ArrowLeft className="mr-1 h-4 w-4" />
            Exit Interview
          </Link>
          <h1 className="text-2xl font-bold">{interview.title}</h1>
          <p className="text-neutral-600">Microsoft Technical Interview Simulation</p>
        </div>
        <div className="flex items-center">
          <div className="flex items-center bg-neutral-100 px-3 py-1.5 rounded-full text-neutral-800">
            <Clock className="h-4 w-4 mr-2 text-neutral-600" />
            <span className="font-medium">{formatTime(timeRemaining)}</span>
          </div>
          <Button
            variant="outline"
            className="ml-4 text-red-600"
            onClick={() => setConfirmExitOpen(true)}
          >
            End Interview
          </Button>
        </div>
      </div>

      {/* Progress bar */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-neutral-600">
            Question {currentQuestionIndex + 1} of {interview.questions.length}
          </span>
          <span className="text-sm font-medium">{Math.round(questionProgress)}% complete</span>
        </div>
        <Progress value={questionProgress} className="h-2" />
      </div>

      {/* Main content */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Left sidebar */}
        <div className="md:col-span-1">
          <Card className="mb-6">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Your Video</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {videoEnabled ? (
                <div className="aspect-video bg-neutral-900 rounded-md flex items-center justify-center text-white mb-4">
                  <Camera className="h-12 w-12 opacity-30" />
                </div>
              ) : (
                <div className="aspect-video bg-neutral-900 rounded-md flex items-center justify-center text-white mb-4">
                  <VideoOff className="h-12 w-12 opacity-30" />
                  <p className="text-sm opacity-70 mt-2">Video disabled</p>
                </div>
              )}
              
              <div className="flex justify-center space-x-2">
                <Button 
                  variant="outline" 
                  size="icon"
                  className={!audioEnabled ? "bg-red-50 text-red-600" : ""}
                  onClick={toggleAudio}
                >
                  {audioEnabled ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
                </Button>
                <Button 
                  variant="outline" 
                  size="icon"
                  className={!videoEnabled ? "bg-red-50 text-red-600" : ""}
                  onClick={toggleVideo}
                >
                  {videoEnabled ? <Video className="h-4 w-4" /> : <VideoOff className="h-4 w-4" />}
                </Button>
                <Button 
                  variant="outline" 
                  size="icon"
                  className={isRecording ? "bg-red-50 text-red-600" : ""}
                  onClick={toggleRecording}
                >
                  <Film className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Question Navigator</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="grid grid-cols-5 gap-2">
                {interview.questions.map((question: InterviewQuestion, index: number) => (
                  <Button
                    key={index}
                    variant={currentQuestionIndex === index ? "default" : "outline"}
                    className="h-10 w-10 p-0"
                    onClick={() => setCurrentQuestionIndex(index)}
                  >
                    {index + 1}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main content */}
        <div className="md:col-span-3">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start mb-2">
                <Badge variant="outline" className={typeColor}>
                  <div className="flex items-center space-x-1">
                    {typeIcon}
                    <span className="ml-1 capitalize">{currentQuestion.type.replace("-", " ")}</span>
                  </div>
                </Badge>
              </div>
              <CardTitle className="text-xl">{currentQuestion.question}</CardTitle>
            </CardHeader>
            <CardContent>
              {currentQuestion.type === 'coding' && (
                <div className="bg-neutral-50 p-4 rounded-md font-mono text-sm mb-6 overflow-x-auto">
                  <pre>{currentQuestion.codeSnippet}</pre>
                </div>
              )}
              
              {showHints && (
                <div className="bg-blue-50 p-4 rounded-md mb-6">
                  <h3 className="font-medium text-blue-700 mb-2">Hints:</h3>
                  <ul className="list-disc pl-5 space-y-1 text-blue-700">
                    {currentQuestion.hints.map((hint: string, idx: number) => (
                      <li key={idx}>{hint}</li>
                    ))}
                  </ul>
                </div>
              )}
              
              <Tabs defaultValue="text" className="w-full mb-4">
                <TabsList>
                  <TabsTrigger value="text">Text Response</TabsTrigger>
                  <TabsTrigger value="voice">Voice Response</TabsTrigger>
                </TabsList>
                <TabsContent value="text">
                  <Textarea
                    placeholder="Type your answer here..."
                    className="min-h-[200px] mt-2"
                    value={answer}
                    onChange={(e) => setAnswer(e.target.value)}
                  />
                </TabsContent>
                <TabsContent value="voice">
                  <div className="flex flex-col items-center justify-center min-h-[200px] bg-neutral-50 rounded-md mt-2 p-4">
                    <Mic className="h-12 w-12 text-neutral-400 mb-4" />
                    <p className="text-neutral-600 mb-2">Click to start recording your answer</p>
                    <Button>Start Recording</Button>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="flex space-x-2">
                <Button variant="outline" onClick={() => setShowHints(!showHints)}>
                  {showHints ? "Hide Hints" : "Show Hints"}
                </Button>
              </div>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  onClick={goToPreviousQuestion}
                  disabled={currentQuestionIndex === 0}
                >
                  <ChevronLeft className="mr-1 h-4 w-4" />
                  Previous
                </Button>
                <Button
                  onClick={goToNextQuestion}
                  disabled={currentQuestionIndex === interview.questions.length - 1}
                >
                  Next
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Button>
                {currentQuestionIndex === interview.questions.length - 1 && (
                  <Button variant="default" onClick={handleEndInterview}>
                    Submit Interview
                  </Button>
                )}
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>

      {/* Exit confirmation dialog */}
      <Dialog open={confirmExitOpen} onOpenChange={setConfirmExitOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Exit Interview?</DialogTitle>
            <DialogDescription>
              Are you sure you want to exit the interview? Your progress will be lost.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmExitOpen(false)}>
              Cancel
            </Button>
            <Link href={`/interviews/${interviewId}`}>
              <Button variant="destructive">Yes, Exit Interview</Button>
            </Link>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* End interview dialog */}
      <Dialog open={endInterviewDialogOpen} onOpenChange={setEndInterviewDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Submit Interview</DialogTitle>
            <DialogDescription>
              Are you ready to submit your interview responses? You will not be able to make changes after submission.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEndInterviewDialogOpen(false)}>
              Cancel
            </Button>
            <Link href={`/interviews/${interviewId}`}>
              <Button>Submit Interview</Button>
            </Link>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};



export default InterviewPractice;