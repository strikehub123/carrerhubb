import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import ExamResultsComponent from "@/components/exam/ExamResults";
import { useAuth } from "@/lib/auth";

const ExamResults = () => {
  const { id, resultId } = useParams<{ id: string; resultId: string }>();
  const examId = parseInt(id);
  const resultIdInt = parseInt(resultId);
  const { user } = useAuth();

  // Fetch result details
  const { data: result, isLoading, error } = useQuery({
    queryKey: [`/api/exam-results/${resultIdInt}`],
    enabled: !isNaN(resultIdInt) && !!user,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  if (isNaN(examId) || isNaN(resultIdInt)) {
    return (
      <div className="bg-neutral-100 py-12">
        <div className="container mx-auto px-4">
          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <h3 className="font-semibold text-lg mb-2">Invalid Result ID</h3>
            <p className="text-neutral-600">
              The result ID provided is invalid. Please try again with a valid ID.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="bg-neutral-100 py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md overflow-hidden animate-pulse">
            <div className="bg-neutral-200 p-6 border-b">
              <div className="h-8 w-48 bg-neutral-300 rounded mx-auto mb-2"></div>
              <div className="h-4 w-32 bg-neutral-300 rounded mx-auto"></div>
            </div>
            
            <div className="p-6">
              <div className="flex flex-col md:flex-row justify-between mb-8">
                <div className="h-20 w-64 bg-neutral-200 rounded mb-4"></div>
                <div className="h-16 w-32 bg-neutral-200 rounded"></div>
              </div>
              
              <div className="mb-8">
                <div className="h-6 w-48 bg-neutral-200 rounded mb-4"></div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="h-24 w-full bg-neutral-200 rounded"></div>
                  ))}
                </div>
              </div>
              
              <div className="mb-8">
                <div className="h-6 w-48 bg-neutral-200 rounded mb-4"></div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="h-24 w-full bg-neutral-200 rounded"></div>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-between">
                <div className="h-10 w-32 bg-neutral-200 rounded"></div>
                <div className="h-10 w-64 bg-neutral-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !result) {
    return (
      <div className="bg-neutral-100 py-12">
        <div className="container mx-auto px-4">
          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <h3 className="font-semibold text-lg mb-2">Result Not Found</h3>
            <p className="text-neutral-600">
              We couldn't find the exam result you're looking for. It may have been removed or you may have followed an invalid link.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-neutral-100 py-12">
      <div className="container mx-auto px-4">
        <ExamResultsComponent result={result} />
      </div>
    </div>
  );
};

export default ExamResults;
