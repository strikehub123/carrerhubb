import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import CourseDetailComponent from "@/components/course/CourseDetail";
import { Course, Module, Lesson } from "@/lib/types";

const CourseDetail = () => {
  const { id } = useParams<{ id: string }>();
  const courseId = parseInt(id);

  // Fetch course details
  const { data: course, isLoading: isLoadingCourse, error: courseError } = useQuery({
    queryKey: [`/api/courses/${courseId}`],
    enabled: !isNaN(courseId),
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Fetch course modules
  const { data: modules, isLoading: isLoadingModules, error: modulesError } = useQuery({
    queryKey: [`/api/courses/${courseId}/modules`],
    enabled: !isNaN(courseId),
    staleTime: 5 * 60 * 1000,
  });

  // Create a map to store lessons for each module
  const { data: lessonsMap, isLoading: isLoadingLessons } = useQuery({
    queryKey: [`/api/courses/${courseId}/lessons`],
    enabled: !isNaN(courseId) && !!modules && modules.length > 0,
    queryFn: async () => {
      // Fetch lessons for each module in parallel
      const lessonsPromises = modules.map((module: Module) =>
        fetch(`/api/modules/${module.id}/lessons`, { credentials: "include" })
          .then((res) => res.json())
          .then((lessons) => ({ moduleId: module.id, lessons }))
      );

      const moduleLessons = await Promise.all(lessonsPromises);

      // Convert to a map where keys are moduleIds and values are arrays of lessons
      const map: Record<number, Lesson[]> = {};
      moduleLessons.forEach(({ moduleId, lessons }) => {
        map[moduleId] = lessons;
      });

      return map;
    },
    staleTime: 5 * 60 * 1000,
  });

  const isLoading = isLoadingCourse || isLoadingModules || isLoadingLessons;
  const error = courseError || modulesError;

  if (isNaN(courseId)) {
    return (
      <div className="bg-neutral-100 py-12">
        <div className="container mx-auto px-4">
          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <h3 className="font-semibold text-lg mb-2">Invalid Course ID</h3>
            <p className="text-neutral-600">
              The course ID provided is invalid. Please try again with a valid ID.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="bg-neutral-100 py-12">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md overflow-hidden animate-pulse">
            <div className="w-full h-64 bg-neutral-200"></div>
            <div className="p-8">
              <div className="h-8 bg-neutral-200 rounded mb-4 w-1/2"></div>
              <div className="h-4 bg-neutral-200 rounded mb-2 w-full"></div>
              <div className="h-4 bg-neutral-200 rounded mb-6 w-3/4"></div>
              
              <div className="h-6 bg-neutral-200 rounded mb-4 w-1/4"></div>
              <div className="grid grid-cols-2 gap-4 mb-6">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="h-4 bg-neutral-200 rounded w-full"></div>
                ))}
              </div>
              
              <div className="h-6 bg-neutral-200 rounded mb-4 w-1/4"></div>
              <div className="space-y-3 mb-6">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="h-12 bg-neutral-200 rounded w-full"></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !course) {
    return (
      <div className="bg-neutral-100 py-12">
        <div className="container mx-auto px-4">
          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <h3 className="font-semibold text-lg mb-2">Course Not Found</h3>
            <p className="text-neutral-600">
              We couldn't find the course you're looking for. It may have been removed or you may have followed an invalid link.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-neutral-100 py-12">
      <div className="container mx-auto px-4">
        <CourseDetailComponent
          course={course}
          modules={modules || []}
          lessonsMap={lessonsMap || {}}
        />
      </div>
    </div>
  );
};

export default CourseDetail;
