import React from 'react';
import { Button } from "@/components/ui/button";
import { Download, FileIcon, Github } from "lucide-react";
import { Link } from 'wouter';

const DownloadPage = () => {
  const downloadFile = () => {
    const downloadLink = document.createElement('a');
    downloadLink.href = '/download/learning-platform-20250328.zip';
    downloadLink.download = 'learning-platform-20250328.zip';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };

  return (
    <div className="container mx-auto py-16 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="bg-gradient-to-b from-primary/20 to-background p-8 rounded-lg shadow-lg border border-border">
          <div className="flex justify-center mb-6">
            <FileIcon className="h-16 w-16 text-primary" />
          </div>
          
          <h1 className="text-3xl font-bold text-center mb-6">
            Download Learning Platform
          </h1>
          
          <p className="text-lg text-muted-foreground mb-6 text-center">
            Get the complete source code for the Learning Platform application. 
            This package includes all frontend and backend code needed to run the application.
          </p>
          
          <div className="bg-card p-6 rounded-md border border-border mb-8">
            <h3 className="text-xl font-semibold mb-2">Package Contents:</h3>
            <ul className="space-y-2 mb-4">
              <li className="flex items-start">
                <span className="text-primary mr-2">•</span>
                <span>React frontend with TailwindCSS and Shadcn UI components</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">•</span>
                <span>Express.js backend with RESTful API endpoints</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">•</span>
                <span>In-memory database implementation (easily extendable to PostgreSQL)</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">•</span>
                <span>Complete authentication system</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">•</span>
                <span>Sample courses, exams, and practice papers</span>
              </li>
            </ul>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">File size: <span className="text-muted-foreground">144 KB</span></p>
                <p className="text-xs text-muted-foreground">learning-platform-20250328.zip</p>
              </div>
              <Button onClick={downloadFile} className="flex items-center gap-2">
                <Download className="h-4 w-4" />
                Download Package
              </Button>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Installation Instructions:</h3>
            <div className="bg-black/90 p-4 rounded-md text-white font-mono text-sm space-y-2 overflow-x-auto">
              <p>$ unzip learning-platform-20250328.zip</p>
              <p>$ cd learning-platform</p>
              <p>$ npm install</p>
              <p>$ npm run dev</p>
            </div>
            <p className="text-muted-foreground text-sm">
              After running these commands, you can access the application at <span className="bg-muted px-1 py-0.5 rounded">http://localhost:3000</span>
            </p>
          </div>
          
          <div className="mt-8 text-center">
            <Link href="/">
              <Button variant="outline" className="mr-4">
                Return to Home
              </Button>
            </Link>
            <a href="https://github.com" target="_blank" rel="noreferrer">
              <Button variant="ghost" className="flex items-center gap-2">
                <Github className="h-4 w-4" />
                View on GitHub
              </Button>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DownloadPage;