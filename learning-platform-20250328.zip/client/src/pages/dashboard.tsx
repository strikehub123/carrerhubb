import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import ProgressSummary from "@/components/dashboard/ProgressSummary";
import ContinueLearning from "@/components/dashboard/ContinueLearning";
import RecommendedExams from "@/components/dashboard/RecommendedExams";
import { Calendar, Clock } from "lucide-react";

const Dashboard = () => {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated, isLoading } = useAuth();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setLocation("/");
    }
  }, [isLoading, isAuthenticated, setLocation]);

  if (isLoading) {
    return (
      <div className="bg-neutral-100 py-12">
        <div className="container mx-auto px-4">
          <div className="h-10 w-64 bg-neutral-200 rounded mb-6 animate-pulse"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 animate-pulse">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-52 bg-neutral-200 rounded"></div>
            ))}
          </div>
          <div className="h-8 w-48 bg-neutral-200 rounded mb-6 animate-pulse"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 animate-pulse">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-64 bg-neutral-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect in useEffect
  }

  return (
    <div className="bg-neutral-100 py-12">
      <div className="container mx-auto px-4">
        <div className="mb-6">
          <h1 className="text-2xl md:text-3xl font-bold mb-2">Your Dashboard</h1>
          <p className="text-neutral-700">Track your progress and continue learning</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <ProgressSummary />

          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="font-semibold mb-4">Upcoming Deadlines</h2>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="bg-error/10 text-error p-2 rounded-md mr-3">
                  <Calendar className="h-4 w-4" />
                </div>
                <div>
                  <div className="font-medium">System Design Quiz</div>
                  <div className="text-sm text-neutral-700">Due in 2 days</div>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-warning/10 text-warning p-2 rounded-md mr-3">
                  <Calendar className="h-4 w-4" />
                </div>
                <div>
                  <div className="font-medium">Algorithms Assignment</div>
                  <div className="text-sm text-neutral-700">Due in 5 days</div>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-neutral-200 text-neutral-700 p-2 rounded-md mr-3">
                  <Calendar className="h-4 w-4" />
                </div>
                <div>
                  <div className="font-medium">Mock Interview Session</div>
                  <div className="text-sm text-neutral-700">In 2 weeks</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="font-semibold mb-4">Study Streaks</h2>
            <div className="flex flex-col items-center justify-center h-full">
              <div className="relative mb-4">
                <div className="w-24 h-24 rounded-full border-4 border-primary flex items-center justify-center">
                  <Clock className="h-12 w-12 text-primary" />
                </div>
                <div className="absolute top-0 right-0 bg-success rounded-full w-8 h-8 flex items-center justify-center text-white font-bold border-2 border-white">
                  5
                </div>
              </div>
              <div className="text-center">
                <div className="font-bold text-lg mb-1">5-Day Streak!</div>
                <p className="text-sm text-neutral-600">
                  Keep it up! You're making great progress.
                </p>
              </div>
            </div>
          </div>
        </div>

        <ContinueLearning />
        
        <RecommendedExams />
      </div>
    </div>
  );
};

export default Dashboard;
