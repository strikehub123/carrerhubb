import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  Clock,
  User,
  Star,
  Briefcase,
  Code,
  Server,
  Monitor,
  Database,
  Cloud,
  MessageSquare,
  Play,
  FileText,
  ListChecks,
  Check,
  CircleHelp,
  ArrowLeft
} from "lucide-react";

import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../components/ui/tabs";
import { Badge } from "../components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "../components/ui/accordion";

// Mock interview data for the detail page
const getInterviewDetails = (id: number) => {
  return {
    id,
    title: "Technical Java Developer Interview",
    company: "Microsoft",
    category: "programming",
    difficulty: "Intermediate",
    duration: 45,
    questions: 10,
    completions: 2500,
    rating: 4.8,
    description: "Practice for Microsoft's technical Java developer interview with this comprehensive simulation. This interview covers core Java concepts, data structures, algorithms, system design, and problem-solving skills that are commonly tested in Microsoft's interview process.",
    overview: [
      "10 challenging technical questions based on real interviews",
      "Mix of coding, conceptual and system design questions",
      "Detailed explanations and sample answers",
      "Performance evaluation compared to other candidates",
      "Customized feedback on your strengths and areas for improvement"
    ],
    sections: [
      {
        id: 1,
        title: "Java Fundamentals",
        questions: 3,
        topics: ["Object-oriented programming", "Collections", "Exception handling"]
      },
      {
        id: 2,
        title: "Data Structures & Algorithms",
        questions: 4,
        topics: ["Array manipulation", "Dynamic programming", "Graph algorithms", "Time & space complexity"]
      },
      {
        id: 3,
        title: "System Design",
        questions: 1,
        topics: ["Scalable architecture", "Microservices", "API design"]
      },
      {
        id: 4,
        title: "Problem Solving",
        questions: 2,
        topics: ["Debugging scenarios", "Edge cases", "Optimization"]
      }
    ],
    faqs: [
      {
        question: "How does the interview simulation work?",
        answer: "Our interview simulation presents you with real-world technical questions and gives you a time limit to respond. You'll be evaluated on your approach, code quality, and correctness. After completing the simulation, you'll receive detailed feedback and performance metrics."
      },
      {
        question: "Is this similar to a real Microsoft interview?",
        answer: "Yes, this simulation is designed to closely mirror Microsoft's actual interview process. The questions are based on real interviews and cover similar topics and difficulty levels that you would encounter in a Microsoft Java developer interview."
      },
      {
        question: "Can I pause the interview and resume later?",
        answer: "No, to make the experience as authentic as possible, once you start the interview, you should complete it in one sitting. This simulates the time pressure of a real interview."
      },
      {
        question: "What if I don't know the answer to a question?",
        answer: "Just like in a real interview, it's okay to not know every answer. We encourage you to describe your thought process and approach the problem systematically. After the simulation, you'll be able to review model answers and explanations."
      }
    ],
    reviews: [
      {
        id: 1,
        name: "Alex Johnson",
        rating: 5,
        comment: "Incredibly helpful! The questions were very similar to what I faced in my actual Microsoft interview."
      },
      {
        id: 2,
        name: "Sarah Chen",
        rating: 4,
        comment: "Great practice resource. The feedback was detailed and helped me identify my weak areas."
      },
      {
        id: 3,
        name: "Michael Rodriguez",
        rating: 5,
        comment: "Passed my Microsoft interview after practicing with this. The system design question was spot on!"
      }
    ]
  };
};

// Category icons mapping
const categoryIcons = {
  programming: <Code className="h-5 w-5" />,
  "web-development": <Monitor className="h-5 w-5" />,
  "data-science": <Database className="h-5 w-5" />,
  "machine-learning": <Server className="h-5 w-5" />,
  devops: <Cloud className="h-5 w-5" />,
};

// Category color schemes
const categoryColors = {
  programming: "bg-blue-50 text-blue-700 border-blue-200",
  "web-development": "bg-purple-50 text-purple-700 border-purple-200",
  "data-science": "bg-green-50 text-green-700 border-green-200",
  "machine-learning": "bg-orange-50 text-orange-700 border-orange-200",
  devops: "bg-teal-50 text-teal-700 border-teal-200",
};

const InterviewDetail = () => {
  const [, params] = useRoute("/interviews/:id");
  const interviewId = params?.id ? parseInt(params.id) : 1;

  // Fetch interview details
  const { data: interview, isLoading } = useQuery({
    queryKey: [`/api/interviews/${interviewId}`],
    queryFn: () => new Promise((resolve) => {
      setTimeout(() => {
        resolve(getInterviewDetails(interviewId));
      }, 500);
    })
  });

  const [activeTab, setActiveTab] = useState("overview");

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse">
          <div className="h-8 w-1/2 bg-gray-200 rounded mb-4"></div>
          <div className="h-4 w-3/4 bg-gray-200 rounded mb-8"></div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="h-40 bg-gray-200 rounded mb-6"></div>
              <div className="h-60 bg-gray-200 rounded"></div>
            </div>
            <div>
              <div className="h-80 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!interview) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-2xl font-bold mb-4">Interview not found</h1>
        <p className="mb-6">Sorry, the interview you're looking for doesn't exist or has been removed.</p>
        <Link href="/interviews">
          <Button>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Interviews
          </Button>
        </Link>
      </div>
    );
  }

  const categoryIcon = interview?.category && categoryIcons[interview.category as keyof typeof categoryIcons] 
    ? categoryIcons[interview.category as keyof typeof categoryIcons] 
    : <Briefcase className="h-5 w-5" />;
  
  const categoryColor = interview?.category && categoryColors[interview.category as keyof typeof categoryColors]
    ? categoryColors[interview.category as keyof typeof categoryColors]
    : "bg-gray-50 text-gray-700 border-gray-200";

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/interviews" className="inline-flex items-center text-neutral-600 hover:text-primary mb-4">
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back to Interviews
        </Link>
        
        <div className="flex flex-wrap items-center gap-2 mb-2">
          <Badge variant="outline" className={categoryColor}>
            <div className="flex items-center space-x-1">
              {categoryIcon}
              <span className="ml-1 capitalize">{interview.category.replace("-", " ")}</span>
            </div>
          </Badge>
          <Badge variant="outline" className="bg-gray-50 text-gray-700">
            {interview.difficulty}
          </Badge>
        </div>
        
        <h1 className="text-3xl font-bold">{interview.title}</h1>
        <div className="flex items-center mt-2 text-neutral-600">
          <Briefcase className="h-4 w-4 mr-1" />
          <span>{interview.company}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="content">Content</TabsTrigger>
              <TabsTrigger value="faqs">FAQs</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold mb-3">About This Interview Simulation</h2>
                <p className="text-neutral-700">{interview.description}</p>
              </div>

              <div>
                <h2 className="text-xl font-semibold mb-3">What You'll Practice</h2>
                <ul className="space-y-2">
                  {interview.overview.map((item, idx) => (
                    <li key={idx} className="flex items-start">
                      <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </TabsContent>

            <TabsContent value="content" className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold mb-3">Interview Sections</h2>
                <Accordion type="single" collapsible className="w-full">
                  {interview.sections.map((section) => (
                    <AccordionItem key={section.id} value={`section-${section.id}`}>
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex justify-between items-center w-full pr-4">
                          <div className="font-medium">{section.title}</div>
                          <div className="text-sm text-neutral-500">{section.questions} questions</div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="pt-2 pb-4">
                          <div className="text-sm text-neutral-600 mb-2">Topics covered:</div>
                          <div className="flex flex-wrap gap-2">
                            {section.topics.map((topic, idx) => (
                              <Badge key={idx} variant="outline">{topic}</Badge>
                            ))}
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </TabsContent>

            <TabsContent value="faqs" className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold mb-3">Frequently Asked Questions</h2>
                <Accordion type="single" collapsible className="w-full">
                  {interview.faqs.map((faq, idx) => (
                    <AccordionItem key={idx} value={`faq-${idx}`}>
                      <AccordionTrigger>{faq.question}</AccordionTrigger>
                      <AccordionContent>
                        <p className="py-2">{faq.answer}</p>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </TabsContent>

            <TabsContent value="reviews" className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-xl font-semibold">User Reviews</h2>
                  <div className="flex items-center">
                    <Star className="h-5 w-5 text-yellow-400 mr-1" />
                    <span className="font-semibold">{interview.rating}</span>
                    <span className="text-neutral-500 ml-1">({interview.reviews.length} reviews)</span>
                  </div>
                </div>
                
                <div className="space-y-4">
                  {interview.reviews.map((review) => (
                    <Card key={review.id}>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium mr-3">
                              {review.name.charAt(0)}
                            </div>
                            <div className="font-medium">{review.name}</div>
                          </div>
                          <div className="flex">
                            {Array(5).fill(0).map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400' : 'text-neutral-200'}`}
                                fill={i < review.rating ? 'currentColor' : 'none'}
                              />
                            ))}
                          </div>
                        </div>
                        <p className="mt-3 text-neutral-700">{review.comment}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <Card className="sticky top-6">
            <CardHeader className="pb-3">
              <CardTitle>Interview Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center text-neutral-600">
                  <Clock className="h-4 w-4 mr-2" />
                  <span>Duration</span>
                </div>
                <span className="font-medium">{interview.duration} min</span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center text-neutral-600">
                  <ListChecks className="h-4 w-4 mr-2" />
                  <span>Questions</span>
                </div>
                <span className="font-medium">{interview.questions}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center text-neutral-600">
                  <User className="h-4 w-4 mr-2" />
                  <span>Completions</span>
                </div>
                <span className="font-medium">{interview.completions.toLocaleString()}</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center text-neutral-600">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  <span>Language</span>
                </div>
                <span className="font-medium">English</span>
              </div>

              <div className="grid grid-cols-2 gap-3 mt-4 mb-2">
                <Link href={`/interviews/${interview.id}/practice`} className="col-span-2">
                  <Button size="lg" className="w-full">
                    <Play className="mr-2 h-4 w-4" />
                    Start Interview
                  </Button>
                </Link>
                <Button variant="outline" className="w-full">
                  <FileText className="mr-2 h-4 w-4" />
                  Preview
                </Button>
                <Button variant="outline" className="w-full">
                  <CircleHelp className="mr-2 h-4 w-4" />
                  Help
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default InterviewDetail;