import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  ChevronRight,
  Search,
  Briefcase,
  Code,
  Server,
  Monitor,
  Database,
  Cloud,
  Filter
} from "lucide-react";

import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

// Mock data for interviews
const interviewsMockData = [
  {
    id: 1,
    title: "Technical Java Developer Interview",
    company: "Microsoft",
    category: "programming",
    difficulty: "Intermediate",
    duration: 45,
    questions: 10,
    completions: 2500,
    rating: 4.8,
  },
  {
    id: 2,
    title: "Data Engineer Interview Simulation",
    company: "Amazon",
    category: "data-science",
    difficulty: "Advanced",
    duration: 60,
    questions: 15,
    completions: 1890,
    rating: 4.6,
  },
  {
    id: 3,
    title: "Frontend Developer Technical Screen",
    company: "Google",
    category: "web-development",
    difficulty: "Intermediate",
    duration: 40,
    questions: 8,
    completions: 3200,
    rating: 4.9,
  },
  {
    id: 4,
    title: "Machine Learning Engineer Interview",
    company: "Netflix",
    category: "machine-learning",
    difficulty: "Expert",
    duration: 75,
    questions: 12,
    completions: 980,
    rating: 4.7,
  },
  {
    id: 5,
    title: "DevOps Interview Practice",
    company: "Uber",
    category: "devops",
    difficulty: "Advanced",
    duration: 50,
    questions: 10,
    completions: 1750,
    rating: 4.5,
  },
  {
    id: 6,
    title: "Full Stack Developer Mock Interview",
    company: "Facebook",
    category: "web-development",
    difficulty: "Intermediate",
    duration: 60,
    questions: 12,
    completions: 2150,
    rating: 4.8,
  },
];

// Category icons mapping
const categoryIcons = {
  programming: <Code className="h-5 w-5" />,
  "web-development": <Monitor className="h-5 w-5" />,
  "data-science": <Database className="h-5 w-5" />,
  "machine-learning": <Server className="h-5 w-5" />,
  devops: <Cloud className="h-5 w-5" />,
};

// Category color schemes
const categoryColors = {
  programming: "bg-blue-50 text-blue-700 border-blue-200",
  "web-development": "bg-purple-50 text-purple-700 border-purple-200",
  "data-science": "bg-green-50 text-green-700 border-green-200",
  "machine-learning": "bg-orange-50 text-orange-700 border-orange-200",
  devops: "bg-teal-50 text-teal-700 border-teal-200",
};

const InterviewCard = ({ interview }) => {
  const categoryIcon = categoryIcons[interview.category] || <Briefcase className="h-5 w-5" />;
  const categoryColor = categoryColors[interview.category] || "bg-gray-50 text-gray-700 border-gray-200";

  return (
    <Card className="h-full transition-all hover:shadow-md">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <Badge variant="outline" className={categoryColor}>
            <div className="flex items-center space-x-1">
              {categoryIcon}
              <span className="ml-1 capitalize">{interview.category.replace("-", " ")}</span>
            </div>
          </Badge>
          <Badge variant="outline" className="bg-gray-50 text-gray-700">
            {interview.difficulty}
          </Badge>
        </div>
        <CardTitle className="text-xl mt-2 mb-1">{interview.title}</CardTitle>
        <CardDescription className="flex items-center">
          <Briefcase className="h-4 w-4 mr-1 text-neutral-500" />
          {interview.company}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <div className="text-neutral-500">Duration</div>
            <div className="font-medium">{interview.duration} min</div>
          </div>
          <div className="flex justify-between text-sm">
            <div className="text-neutral-500">Questions</div>
            <div className="font-medium">{interview.questions}</div>
          </div>
          <div className="flex justify-between text-sm">
            <div className="text-neutral-500">Completions</div>
            <div className="font-medium">{interview.completions.toLocaleString()}</div>
          </div>
          
          <div className="pt-3">
            <Link href={`/interviews/${interview.id}`}>
              <Button className="w-full">
                View Interview
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const Interviews = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [difficulty, setDifficulty] = useState("");
  const [category, setCategory] = useState("");

  // Simulating a query
  const { data: interviewsData, isLoading, error } = useQuery({ 
    queryKey: ['/api/interviews'],
    queryFn: () => {
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(interviewsMockData);
        }, 500);
      });
    }
  });

  // Filter interviews based on search query, difficulty and category
  const filteredInterviews = interviewsData ? interviewsData.filter((interview) => {
    const matchesSearch = searchQuery === "" || 
      interview.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      interview.company.toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesDifficulty = difficulty === "" || interview.difficulty.toLowerCase() === difficulty.toLowerCase();
    const matchesCategory = category === "" || interview.category === category;
    
    return matchesSearch && matchesDifficulty && matchesCategory;
  }) : [];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Interview Practice</h1>
          <p className="text-neutral-500 mt-2">
            Practice real-world interview questions from top companies and improve your interview skills
          </p>
        </div>

        {/* Search and filters */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-grow relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400" size={18} />
            <Input
              placeholder="Search interviews by title or company..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Select value={difficulty} onValueChange={setDifficulty}>
              <SelectTrigger className="w-[180px]">
                <div className="flex items-center">
                  <Filter size={16} className="mr-2" />
                  <SelectValue placeholder="Difficulty" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Difficulties</SelectItem>
                <SelectItem value="beginner">Beginner</SelectItem>
                <SelectItem value="intermediate">Intermediate</SelectItem>
                <SelectItem value="advanced">Advanced</SelectItem>
                <SelectItem value="expert">Expert</SelectItem>
              </SelectContent>
            </Select>

            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Categories</SelectItem>
                <SelectItem value="programming">Programming</SelectItem>
                <SelectItem value="web-development">Web Development</SelectItem>
                <SelectItem value="data-science">Data Science</SelectItem>
                <SelectItem value="machine-learning">Machine Learning</SelectItem>
                <SelectItem value="devops">DevOps</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Interview categories tabs */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="all">All Interviews</TabsTrigger>
            <TabsTrigger value="technical">Technical</TabsTrigger>
            <TabsTrigger value="behavioral">Behavioral</TabsTrigger>
            <TabsTrigger value="system-design">System Design</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="m-0">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 py-4">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <Card key={i} className="h-[320px] animate-pulse">
                    <CardHeader className="pb-3">
                      <div className="h-5 w-1/3 bg-gray-200 rounded mb-3"></div>
                      <div className="h-7 w-3/4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-5 w-1/2 bg-gray-200 rounded"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-5">
                        <div className="h-4 w-full bg-gray-200 rounded"></div>
                        <div className="h-4 w-full bg-gray-200 rounded"></div>
                        <div className="h-4 w-full bg-gray-200 rounded"></div>
                        <div className="h-10 w-full bg-gray-200 rounded mt-6"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : error ? (
              <div className="text-center py-10">
                <p className="text-red-600">Error loading interviews. Please try again later.</p>
              </div>
            ) : filteredInterviews.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-neutral-500">No interviews found matching your criteria.</p>
                <Button onClick={() => { setSearchQuery(""); setDifficulty(""); setCategory(""); }} variant="outline" className="mt-4">
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 py-4">
                {filteredInterviews.map((interview) => (
                  <InterviewCard key={interview.id} interview={interview} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="technical" className="m-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 py-4">
              {filteredInterviews
                .filter(interview => ["programming", "web-development", "data-science"].includes(interview.category))
                .map((interview) => (
                  <InterviewCard key={interview.id} interview={interview} />
                ))}
            </div>
          </TabsContent>

          <TabsContent value="behavioral" className="m-0">
            <div className="text-center py-10">
              <p className="text-neutral-500">Behavioral interview practice coming soon!</p>
              <p className="text-sm mt-2">We're working on adding behavioral interview questions and simulations.</p>
            </div>
          </TabsContent>

          <TabsContent value="system-design" className="m-0">
            <div className="text-center py-10">
              <p className="text-neutral-500">System design interview preparation coming soon!</p>
              <p className="text-sm mt-2">We're building interactive system design challenges and practice scenarios.</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Interviews;