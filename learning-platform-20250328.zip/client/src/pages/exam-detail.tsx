import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Clock, 
  FileQuestion, 
  Medal, 
  AlertTriangle,
  BarChart 
} from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

const ExamDetail = () => {
  const { id } = useParams<{ id: string }>();
  const examId = parseInt(id);
  const { user } = useAuth();
  const { toast } = useToast();

  // Fetch exam details
  const { data: exam, isLoading, error } = useQuery({
    queryKey: [`/api/exams/${examId}`],
    enabled: !isNaN(examId),
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const handleStartExam = (paperId: number = 0) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to take this exam",
        variant: "destructive"
      });
      return;
    }
    
    // Navigate to exam interface with optional paper ID
    window.location.href = `/exams/${examId}/take${paperId ? `?paper=${paperId}` : ''}`;
  };

  if (isNaN(examId)) {
    return (
      <div className="bg-neutral-100 py-12">
        <div className="container mx-auto px-4">
          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <h3 className="font-semibold text-lg mb-2">Invalid Exam ID</h3>
            <p className="text-neutral-600">
              The exam ID provided is invalid. Please try again with a valid ID.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="bg-neutral-100 py-12">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-8 animate-pulse">
            <div className="h-8 bg-neutral-200 rounded mb-4 w-1/2"></div>
            <div className="h-4 bg-neutral-200 rounded mb-6 w-full"></div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-20 bg-neutral-200 rounded"></div>
              ))}
            </div>
            
            <div className="h-6 bg-neutral-200 rounded mb-4 w-1/4"></div>
            <div className="h-32 bg-neutral-200 rounded mb-6"></div>
            
            <div className="flex justify-center">
              <div className="h-10 w-48 bg-neutral-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !exam) {
    return (
      <div className="bg-neutral-100 py-12">
        <div className="container mx-auto px-4">
          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <h3 className="font-semibold text-lg mb-2">Exam Not Found</h3>
            <p className="text-neutral-600">
              We couldn't find the exam you're looking for. It may have been removed or you may have followed an invalid link.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Determine difficulty color
  let difficultyColor = "text-[#00CC99]";
  let difficultyBg = "bg-[#00CC99]/10";
  
  if (exam.difficulty === "Advanced") {
    difficultyColor = "text-[#F59E0B]";
    difficultyBg = "bg-[#F59E0B]/10";
  } else if (exam.difficulty === "Beginner-Friendly") {
    difficultyColor = "text-[#22C55E]";
    difficultyBg = "bg-[#22C55E]/10";
  }

  return (
    <div className="bg-neutral-100 py-12">
      <div className="container mx-auto px-4">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-8">
            <h1 className="text-2xl font-bold mb-2">{exam.title}</h1>
            <p className="text-neutral-700 mb-6">{exam.description}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-neutral-100 p-4 rounded-lg">
                <div className="flex items-start">
                  <Clock className="text-primary mt-1 mr-3 h-5 w-5" />
                  <div>
                    <div className="font-medium mb-1">Duration</div>
                    <div className="text-neutral-700">{exam.duration} minutes</div>
                  </div>
                </div>
              </div>
              
              <div className="bg-neutral-100 p-4 rounded-lg">
                <div className="flex items-start">
                  <FileQuestion className="text-primary mt-1 mr-3 h-5 w-5" />
                  <div>
                    <div className="font-medium mb-1">Questions</div>
                    <div className="text-neutral-700">{exam.questionCount} multiple-choice questions</div>
                  </div>
                </div>
              </div>
              
              <div className={`${difficultyBg} p-4 rounded-lg`}>
                <div className="flex items-start">
                  <Medal className={`${difficultyColor} mt-1 mr-3 h-5 w-5`} />
                  <div>
                    <div className="font-medium mb-1">Difficulty</div>
                    <div className="text-neutral-700">{exam.difficulty}</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">About This Exam</h2>
              <div className="bg-neutral-100 p-6 rounded-lg">
                <div className="flex mb-4">
                  <BarChart className="text-primary mt-1 mr-3 h-5 w-5" />
                  <div className="font-medium">Exam Statistics</div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-4">
                  <div>
                    <div className="text-sm text-neutral-700 mb-1">Success rate</div>
                    <div className="font-medium">{exam.successRate}%</div>
                    <div className="w-full h-2 bg-neutral-200 rounded-full mt-2">
                      <div 
                        className={`h-full ${
                          exam.successRate < 40 ? "bg-[#F59E0B]" : 
                          exam.successRate < 60 ? "bg-[#00CC99]" : "bg-[#22C55E]"
                        } rounded-full`} 
                        style={{ width: `${exam.successRate}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="text-sm text-neutral-700 mb-1">Pass percentage</div>
                    <div className="font-medium">{exam.passPercentage}%</div>
                  </div>
                  
                  <div>
                    <div className="text-sm text-neutral-700 mb-1">Time allowed</div>
                    <div className="font-medium">{exam.duration} minutes</div>
                  </div>
                </div>
                
                <div className="flex items-start p-4 bg-[#F59E0B]/10 rounded-lg">
                  <AlertTriangle className="text-[#F59E0B] mt-1 mr-3 h-5 w-5" />
                  <div>
                    <div className="font-medium mb-1">Important Note</div>
                    <div className="text-sm text-neutral-700">
                      Once you start the exam, the timer cannot be paused. Make sure you have enough time to complete it. You can flag questions to review later before submitting.
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">Practice Test Papers</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="border border-neutral-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                  <h3 className="font-semibold text-lg mb-2">Paper 1</h3>
                  <p className="text-neutral-600 mb-4">
                    Standard practice paper with a mix of algorithms, data structures, and system design questions.
                  </p>
                  <div className="flex items-center text-sm text-neutral-500 mb-4">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>{Math.round(exam.duration * 0.8)} minutes</span>
                    <span className="mx-2">•</span>
                    <FileQuestion className="h-4 w-4 mr-1" />
                    <span>{Math.round(exam.questionCount * 0.7)} questions</span>
                  </div>
                  <Button onClick={(e) => handleStartExam(1)} variant="outline" className="w-full">
                    Start Practice Paper 1
                  </Button>
                </div>
                
                <div className="border border-neutral-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                  <h3 className="font-semibold text-lg mb-2">Paper 2</h3>
                  <p className="text-neutral-600 mb-4">
                    Advanced practice paper with more challenging questions focused on system design and optimization.
                  </p>
                  <div className="flex items-center text-sm text-neutral-500 mb-4">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>{Math.round(exam.duration * 0.85)} minutes</span>
                    <span className="mx-2">•</span>
                    <FileQuestion className="h-4 w-4 mr-1" />
                    <span>{Math.round(exam.questionCount * 0.75)} questions</span>
                  </div>
                  <Button onClick={(e) => handleStartExam(2)} variant="outline" className="w-full">
                    Start Practice Paper 2
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="flex justify-center">
              <Button
                size="lg"
                onClick={(e) => handleStartExam()}
                className="px-8"
              >
                Start Full Exam
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExamDetail;
