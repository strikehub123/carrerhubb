import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, useRoute } from "wouter";
import { Course, Category } from "@/lib/types";
import CourseCard from "@/components/course/CourseCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter, X, Code, Server, Monitor, Database, Cloud } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

// Subject icons mapping
const subjectIcons = {
  programming: <Code className="h-5 w-5" />,
  "web-development": <Monitor className="h-5 w-5" />,
  "data-science": <Database className="h-5 w-5" />,
  "machine-learning": <Server className="h-5 w-5" />,
  devops: <Cloud className="h-5 w-5" />,
};

// Subject name mapping (for display)
const subjectNames = {
  programming: "Programming",
  "web-development": "Web Development",
  "data-science": "Data Science",
  "machine-learning": "Machine Learning",
  devops: "DevOps",
};

const Courses = () => {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);

  // Check for subject in URL
  const [match, params] = useRoute("/courses/subject/:subject");
  const subjectFromRoute = match ? params?.subject : null;

  // Get search params from URL
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const categoryFromUrl = searchParams.get("category");

  // Set initial category from URL if present
  useEffect(() => {
    if (categoryFromUrl) {
      setSelectedCategory(categoryFromUrl);
    }
  }, [categoryFromUrl]);

  // Set selected subject from route if present
  useEffect(() => {
    if (subjectFromRoute) {
      setSelectedSubject(subjectFromRoute);
    }
  }, [subjectFromRoute]);

  // Fetch courses and categories
  const { data: courses, isLoading: isLoadingCourses } = useQuery({
    queryKey: ['/api/courses'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const { data: categories, isLoading: isLoadingCategories } = useQuery({
    queryKey: ['/api/categories'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Get the appropriate subject name for display
  const subjectName = selectedSubject ? subjectNames[selectedSubject] || selectedSubject : null;
  const subjectIcon = selectedSubject ? subjectIcons[selectedSubject] : null;

  // Apply filters to courses
  const filteredCourses = courses?.filter((course: Course) => {
    // Filter by search query
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Filter by category
    const matchesCategory = selectedCategory === "all" || course.categoryId.toString() === selectedCategory;
    
    // Filter by difficulty
    const matchesDifficulty = selectedDifficulty === "all" || course.difficulty === selectedDifficulty;
    
    // Filter by subject (if one is selected)
    // Note: This would need to be updated to use real subject data from the API
    // For now, we're simulating this filter based on course names/descriptions
    const matchesSubject = !selectedSubject || 
                           course.title.toLowerCase().includes(selectedSubject.toLowerCase()) || 
                           course.description.toLowerCase().includes(selectedSubject.toLowerCase());
    
    return matchesSearch && matchesCategory && matchesDifficulty && matchesSubject;
  });

  const toggleFilters = () => {
    setIsFiltersOpen(!isFiltersOpen);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Apply search filter
  };

  const resetFilters = () => {
    setSearchQuery("");
    setSelectedCategory("all");
    setSelectedDifficulty("all");
    if (selectedSubject) {
      setSelectedSubject(null);
      setLocation("/courses");
    }
  };

  const isLoading = isLoadingCourses || isLoadingCategories;

  const clearSubject = () => {
    setSelectedSubject(null);
    setLocation("/courses");
  };

  return (
    <div className="bg-neutral-100 py-12">
      <div className="container mx-auto px-4">
        {/* Subject banner if a subject is selected */}
        {selectedSubject && (
          <div className="bg-white rounded-lg shadow-sm p-4 mb-6 flex items-center justify-between">
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-3">
                {subjectIcon}
              </div>
              <div>
                <h2 className="text-xl font-semibold">{subjectName} Courses</h2>
                <p className="text-neutral-600 text-sm">Browse all courses related to {subjectName}</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={clearSubject}>
              <X className="h-4 w-4 mr-1" />
              Clear subject
            </Button>
          </div>
        )}
        
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
          <h1 className="text-2xl md:text-3xl font-bold mb-4 md:mb-0">
            {selectedSubject ? `${subjectName} Courses` : "All Courses"}
          </h1>
          
          <div className="flex items-center">
            <form onSubmit={handleSearch} className="relative flex-grow mr-2">
              <Input
                type="text"
                placeholder="Search courses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
              />
              <button
                type="submit"
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-neutral-400"
              >
                <Search size={18} />
              </button>
            </form>
            
            <Button
              variant="outline"
              size="icon"
              onClick={toggleFilters}
              className="md:hidden"
            >
              <Filter size={18} />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mb-8">
          {/* Filters - Desktop */}
          <div className="hidden md:block bg-white rounded-lg shadow-sm p-6">
            <div className="mb-6">
              <h2 className="font-semibold mb-3">Categories</h2>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="category-all"
                    name="category"
                    value="all"
                    checked={selectedCategory === "all"}
                    onChange={() => setSelectedCategory("all")}
                    className="mr-2"
                  />
                  <label htmlFor="category-all">All Categories</label>
                </div>
                
                {categories?.map((category: Category) => (
                  <div key={category.id} className="flex items-center">
                    <input
                      type="radio"
                      id={`category-${category.id}`}
                      name="category"
                      value={category.id.toString()}
                      checked={selectedCategory === category.id.toString()}
                      onChange={() => setSelectedCategory(category.id.toString())}
                      className="mr-2"
                    />
                    <label htmlFor={`category-${category.id}`}>{category.name}</label>
                  </div>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <h2 className="font-semibold mb-3">Difficulty</h2>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="difficulty-all"
                    name="difficulty"
                    value="all"
                    checked={selectedDifficulty === "all"}
                    onChange={() => setSelectedDifficulty("all")}
                    className="mr-2"
                  />
                  <label htmlFor="difficulty-all">All Levels</label>
                </div>
                
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="difficulty-beginner"
                    name="difficulty"
                    value="Beginner"
                    checked={selectedDifficulty === "Beginner"}
                    onChange={() => setSelectedDifficulty("Beginner")}
                    className="mr-2"
                  />
                  <label htmlFor="difficulty-beginner">Beginner</label>
                </div>
                
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="difficulty-intermediate"
                    name="difficulty"
                    value="Intermediate"
                    checked={selectedDifficulty === "Intermediate"}
                    onChange={() => setSelectedDifficulty("Intermediate")}
                    className="mr-2"
                  />
                  <label htmlFor="difficulty-intermediate">Intermediate</label>
                </div>
                
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="difficulty-advanced"
                    name="difficulty"
                    value="Advanced"
                    checked={selectedDifficulty === "Advanced"}
                    onChange={() => setSelectedDifficulty("Advanced")}
                    className="mr-2"
                  />
                  <label htmlFor="difficulty-advanced">Advanced</label>
                </div>
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full"
              onClick={resetFilters}
            >
              Reset Filters
            </Button>
          </div>

          {/* Filters - Mobile */}
          {isFiltersOpen && (
            <div className="md:hidden fixed inset-0 bg-black/50 z-50 flex justify-end">
              <div className="bg-white h-full w-4/5 overflow-auto p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="font-bold text-lg">Filters</h2>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={toggleFilters}
                  >
                    <X size={20} />
                  </Button>
                </div>
                
                <div className="mb-6">
                  <h3 className="font-semibold mb-3">Categories</h3>
                  <Select
                    value={selectedCategory}
                    onValueChange={setSelectedCategory}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {categories?.map((category: Category) => (
                        <SelectItem key={category.id} value={category.id.toString()}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="mb-6">
                  <h3 className="font-semibold mb-3">Difficulty</h3>
                  <Select
                    value={selectedDifficulty}
                    onValueChange={setSelectedDifficulty}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select Difficulty" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="Beginner">Beginner</SelectItem>
                      <SelectItem value="Intermediate">Intermediate</SelectItem>
                      <SelectItem value="Advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex flex-col space-y-3">
                  <Button onClick={resetFilters} variant="outline">
                    Reset Filters
                  </Button>
                  <Button onClick={toggleFilters}>
                    Apply Filters
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Courses Grid */}
          <div className="lg:col-span-3">
            {isLoading ? (
              // Loading state
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="bg-white rounded-lg overflow-hidden shadow-sm animate-pulse">
                    <div className="w-full h-48 bg-neutral-200"></div>
                    <div className="p-6">
                      <div className="h-6 bg-neutral-200 rounded mb-4"></div>
                      <div className="h-4 bg-neutral-200 rounded mb-2"></div>
                      <div className="h-4 bg-neutral-200 rounded mb-2"></div>
                      <div className="h-4 bg-neutral-200 rounded w-2/3 mb-4"></div>
                      <div className="flex justify-between items-center">
                        <div className="h-6 w-16 bg-neutral-200 rounded"></div>
                        <div className="h-4 w-20 bg-neutral-200 rounded"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredCourses?.length > 0 ? (
              // Courses found
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCourses.map((course: Course) => (
                  <CourseCard key={course.id} course={course} />
                ))}
              </div>
            ) : (
              // No courses found
              <div className="bg-white p-8 rounded-lg shadow-sm text-center">
                <h3 className="font-semibold text-lg mb-2">No courses found</h3>
                <p className="text-neutral-600 mb-4">
                  We couldn't find any courses matching your search criteria.
                </p>
                <Button onClick={resetFilters}>Clear Filters</Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Courses;
