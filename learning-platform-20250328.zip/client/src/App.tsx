import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "./components/ui/toaster";
import { AuthProvider } from "./lib/auth";
import NotFound from "./pages/not-found";
import Header from "./components/layout/Header";
import Footer from "./components/layout/Footer";
import Home from "./pages/home";
import Courses from "./pages/courses";
import CourseDetail from "./pages/course-detail";
import Exams from "./pages/exams";
import ExamDetail from "./pages/exam-detail";
import ExamInterface from "./pages/exam-interface";
import ExamResults from "./pages/exam-results";
import Dashboard from "./pages/dashboard";
import Interviews from "./pages/interviews";
import InterviewDetail from "./pages/interview-detail";
import InterviewPractice from "./pages/interview-practice";
import Login from "./pages/login";
import Register from "./pages/register";
import Profile from "./pages/profile";
import Settings from "./pages/settings";
import Purchase from "./pages/purchase";
import Download from "./pages/download";

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={Home} />
          {/* Course routes */}
          <Route path="/courses" component={Courses} />
          <Route path="/courses/subject/:subject" component={Courses} />
          <Route path="/courses/:id" component={CourseDetail} />
          
          {/* Exam routes */}
          <Route path="/exams" component={Exams} />
          <Route path="/exams/:id" component={ExamDetail} />
          <Route path="/exams/:id/take" component={ExamInterface} />
          <Route path="/exams/:id/results/:resultId" component={ExamResults} />
          
          {/* Interview routes */}
          <Route path="/interviews" component={Interviews} />
          <Route path="/interviews/:id" component={InterviewDetail} />
          <Route path="/interviews/:id/practice" component={InterviewPractice} />
          
          {/* User routes */}
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route path="/profile" component={Profile} />
          <Route path="/settings" component={Settings} />
          
          {/* Purchase route */}
          <Route path="/courses/:id/purchase" component={Purchase} />
          
          {/* Download route */}
          <Route path="/download" component={Download} />
          
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
