import { create } from "zustand";
import { persist } from "zustand/middleware";

interface ExamState {
  currentQuestionIndex: number;
  answers: Record<number, number>;
  questionStatuses: Record<number, string>;
  examStartTime: number | null;
  flaggedQuestions: number[];

  setCurrentQuestionIndex: (index: number) => void;
  setAnswer: (questionId: number, optionId: number) => void;
  setQuestionStatus: (questionId: number, status: string) => void;
  startExam: () => void;
  flagQuestion: (questionId: number) => void;
  unflagQuestion: (questionId: number) => void;
  resetExam: () => void;
}

const useExamStore = create<ExamState>()(
  persist(
    (set) => ({
      currentQuestionIndex: 0,
      answers: {},
      questionStatuses: {},
      examStartTime: null,
      flaggedQuestions: [],

      setCurrentQuestionIndex: (index) => 
        set(() => ({ currentQuestionIndex: index })),

      setAnswer: (questionId, optionId) =>
        set((state) => ({
          answers: {
            ...state.answers,
            [questionId]: optionId,
          },
        })),

      setQuestionStatus: (questionId, status) =>
        set((state) => ({
          questionStatuses: {
            ...state.questionStatuses,
            [questionId]: status,
          },
        })),

      startExam: () => 
        set(() => ({ examStartTime: Date.now() })),

      flagQuestion: (questionId) =>
        set((state) => ({
          flaggedQuestions: [...state.flaggedQuestions, questionId],
        })),

      unflagQuestion: (questionId) =>
        set((state) => ({
          flaggedQuestions: state.flaggedQuestions.filter(
            (id) => id !== questionId
          ),
        })),

      resetExam: () =>
        set(() => ({
          currentQuestionIndex: 0,
          answers: {},
          questionStatuses: {},
          examStartTime: null,
          flaggedQuestions: [],
        })),
    }),
    {
      name: "exam-storage",
    }
  )
);

interface CourseState {
  expandedModules: Record<number, boolean>;
  lastViewedLesson: Record<number, number>; // courseId -> lessonId

  toggleModule: (moduleId: number) => void;
  setLastViewedLesson: (courseId: number, lessonId: number) => void;
}

const useCourseStore = create<CourseState>()(
  persist(
    (set) => ({
      expandedModules: {},
      lastViewedLesson: {},

      toggleModule: (moduleId) =>
        set((state) => ({
          expandedModules: {
            ...state.expandedModules,
            [moduleId]: !state.expandedModules[moduleId],
          },
        })),

      setLastViewedLesson: (courseId, lessonId) =>
        set((state) => ({
          lastViewedLesson: {
            ...state.lastViewedLesson,
            [courseId]: lessonId,
          },
        })),
    }),
    {
      name: "course-storage",
    }
  )
);

// Export all stores
export { useExamStore, useCourseStore };
