import { create } from "zustand";
import { createContext, useContext, ReactNode, useState, useEffect } from "react";
import { apiRequest } from "./queryClient";
import { User } from "./types";

interface AuthStore {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<User>;
  register: (userData: {
    username: string;
    password: string;
    email: string;
    fullName: string;
  }) => Promise<User>;
  logout: () => void;
  setUser: (user: User | null) => void;
}

// Create a Zustand store for auth state
export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: async (username: string, password: string) => {
    try {
      const userData = await apiRequest("POST", "/api/auth/login", {
        username,
        password,
      });
      set({ user: userData, isAuthenticated: true });
      return userData;
    } catch (error) {
      throw new Error(error instanceof Error ? error.message : "Login failed");
    }
  },
  register: async (userData) => {
    try {
      const newUser = await apiRequest("POST", "/api/auth/register", userData);
      set({ user: newUser, isAuthenticated: true });
      return newUser;
    } catch (error) {
      throw new Error(
        error instanceof Error ? error.message : "Registration failed"
      );
    }
  },
  logout: () => {
    set({ user: null, isAuthenticated: false });
  },
  setUser: (user) => {
    set({ user, isAuthenticated: !!user, isLoading: false });
  },
}));

// Create React context
const AuthContext = createContext<AuthStore | null>(null);

// Auth provider component
interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const auth = useAuthStore();
  const [initialized, setInitialized] = useState(false);

  // On mount, try to get the current user (implement a /me endpoint)
  useEffect(() => {
    const initAuth = async () => {
      try {
        // Mock fetching current user for now
        // In a real app, you would call an API like /api/auth/me
        // const userData = await apiRequest("GET", "/api/auth/me");
        // auth.setUser(userData);
        
        // For the demo, we'll set a mock user
        // In a real implementation, remove this and uncomment the above
        const mockUser: User = {
          id: 1,
          username: "johndoe",
          email: "john.doe@example.com",
          fullName: "John Doe",
          avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e",
          createdAt: new Date(),
        };
        auth.setUser(mockUser);
      } catch (error) {
        auth.setUser(null);
      } finally {
        setInitialized(true);
      }
    };

    initAuth();
  }, []);

  if (!initialized) {
    return null; // or a loading indicator
  }

  return <AuthContext.Provider value={auth}>{children}</AuthContext.Provider>;
};

// Hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
