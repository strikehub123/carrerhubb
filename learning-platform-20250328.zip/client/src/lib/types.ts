// User related types
export interface User {
  id: number;
  username: string;
  email: string;
  fullName: string;
  avatarUrl?: string;
  createdAt: Date;
}

// Category related types
export interface Category {
  id: number;
  name: string;
  description?: string;
  icon: string;
  colorScheme: string;
  courseCount: number;
}

// Course related types
export interface Course {
  id: number;
  title: string;
  description: string;
  imageUrl?: string;
  price: number;
  duration: number; // in minutes
  categoryId: number;
  difficulty: string;
  rating: number;
  ratingCount: number;
  createdAt: Date;
}

// Module related types
export interface Module {
  id: number;
  courseId: number;
  title: string;
  description?: string;
  order: number;
}

// Lesson related types
export interface Lesson {
  id: number;
  moduleId: number;
  title: string;
  content: string;
  videoUrl?: string;
  duration: number; // in minutes
  order: number;
}

// Exam related types
export interface Exam {
  id: number;
  title: string;
  description: string;
  duration: number; // in minutes
  questionCount: number;
  categoryId: number;
  difficulty: string;
  passPercentage: number;
  successRate: number;
}

// Question related types
export interface Question {
  id: number;
  examId: number;
  question: string;
  code?: string;
  type: string;
  category: string;
  difficulty: string;
}

// Option related types
export interface Option {
  id: number;
  questionId: number;
  text: string;
  isCorrect: boolean;
}

// User progress related types
export interface UserProgress {
  id: number;
  userId: number;
  courseId: number;
  completedLessons: number;
  totalLessons: number;
  lastAccessedAt: Date;
  course?: Course;
}

// Exam result related types
export interface ExamResult {
  id: number;
  userId: number;
  examId: number;
  score: number;
  maxScore: number;
  passed: boolean;
  timeSpent: number; // in seconds
  completedAt: Date;
}

// Category score related types
export interface CategoryScore {
  id: number;
  resultId: number;
  category: string;
  score: number;
  maxScore: number;
  percentage: number;
}
