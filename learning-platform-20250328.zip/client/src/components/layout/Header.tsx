import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { 
  Search,
  Bell,
  Menu,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Header = () => {
  const [, setLocation] = useLocation();
  const { user, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Implement search functionality
    console.log("Searching for:", searchQuery);
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleLogout = () => {
    logout();
    setLocation("/");
  };

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-10">
            <Link href="/" className="flex items-center">
              <span className="text-primary text-2xl font-bold">CareerPrep</span>
            </Link>
            
            <nav className="hidden md:flex space-x-8">
              <HeaderLink href="/" label="Home" />
              
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center space-x-1 focus:outline-none text-neutral-700 hover:text-primary font-medium">
                  <span>Courses</span>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start">
                  <DropdownMenuItem asChild>
                    <Link href="/courses" className="w-full">All Courses</Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/courses/subject/programming" className="w-full">Programming</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/courses/subject/data-science" className="w-full">Data Science</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/courses/subject/web-development" className="w-full">Web Development</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/courses/subject/machine-learning" className="w-full">Machine Learning</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/courses/subject/devops" className="w-full">DevOps</Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <HeaderLink href="/exams" label="Exams" />
              <HeaderLink href="/interviews" label="Interviews" />
              {user && <HeaderLink href="/dashboard" label="Dashboard" />}
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            <div className="relative hidden md:block">
              <form onSubmit={handleSearch}>
                <input
                  type="text"
                  placeholder="Search courses and exams..."
                  className="w-64 px-4 py-2 rounded-full border border-neutral-200 focus:outline-none focus:border-primary"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button className="absolute right-3 top-2 text-neutral-400" type="submit">
                  <Search size={18} />
                </button>
              </form>
            </div>

            {user ? (
              <>
                <button className="flex items-center text-neutral-700 hover:text-primary">
                  <Bell size={20} />
                </button>
                
                <DropdownMenu>
                  <DropdownMenuTrigger className="flex items-center space-x-2 focus:outline-none">
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium">
                      {user.fullName.charAt(0)}
                    </div>
                    <span className="hidden md:inline-block font-medium">{user.fullName}</span>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>My Account</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/dashboard">Dashboard</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/profile">Profile</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/settings">Settings</Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="flex space-x-2">
                <Button onClick={() => setLocation("/login")} variant="outline" size="sm">
                  Login
                </Button>
                <Button onClick={() => setLocation("/register")} size="sm">
                  Sign Up
                </Button>
              </div>
            )}

            <button className="md:hidden" onClick={toggleMenu}>
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile search */}
        <div className="block md:hidden pb-3">
          <form onSubmit={handleSearch}>
            <div className="relative">
              <input
                type="text"
                placeholder="Search..."
                className="w-full px-4 py-2 rounded-full border border-neutral-200 focus:outline-none focus:border-primary"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button className="absolute right-3 top-2 text-neutral-400" type="submit">
                <Search size={18} />
              </button>
            </div>
          </form>
        </div>

        {/* Mobile menu */}
        <nav className={`md:hidden overflow-x-auto py-2 space-x-6 ${isMenuOpen ? 'block' : 'hidden'}`}>
          <Link href="/" className="text-primary font-medium whitespace-nowrap">Home</Link>
          <Link href="/courses" className="text-neutral-700 hover:text-primary font-medium whitespace-nowrap">Courses</Link>
          <Link href="/exams" className="text-neutral-700 hover:text-primary font-medium whitespace-nowrap">Exams</Link>
          <Link href="/interviews" className="text-neutral-700 hover:text-primary font-medium whitespace-nowrap">Interviews</Link>
          {user && <Link href="/dashboard" className="text-neutral-700 hover:text-primary font-medium whitespace-nowrap">Dashboard</Link>}
        </nav>
      </div>
    </header>
  );
};

const HeaderLink = ({ href, label }: { href: string; label: string }) => {
  const [location] = useLocation();
  const isActive = location === href;

  return (
    <Link href={href} className={`${isActive ? 'text-primary' : 'text-neutral-700 hover:text-primary'} font-medium`}>
      {label}
    </Link>
  );
};

export default Header;
