import { Link } from "wouter";
import { Facebook, Twitter, Linkedin, Instagram } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-neutral-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">CareerPrep</h3>
            <p className="text-neutral-400 mb-4">
              Master the skills, ace the interviews, and land your dream job with our specialized courses and practice exams.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-400 hover:text-white">
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Courses</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Software Engineering
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Data Science
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Product Management
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  UX/UI Design
                </a>
              </li>
              <li>
                <Link href="/courses" className="text-neutral-400 hover:text-white">
                  All Courses
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Exams</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Practice Tests
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Mock Interviews
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Coding Challenges
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  System Design Exercises
                </a>
              </li>
              <li>
                <Link href="/exams" className="text-neutral-400 hover:text-white">
                  All Exams
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Company</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Careers
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Blog
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="text-neutral-400 hover:text-white">
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-neutral-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="text-neutral-400 mb-4 md:mb-0">
            © {new Date().getFullYear()} CareerPrep. All rights reserved.
          </div>
          <div className="flex space-x-6">
            <a href="#" className="text-neutral-400 hover:text-white text-sm">
              Terms of Service
            </a>
            <a href="#" className="text-neutral-400 hover:text-white text-sm">
              Privacy Policy
            </a>
            <a href="#" className="text-neutral-400 hover:text-white text-sm">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
