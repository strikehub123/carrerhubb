import { Link } from "wouter";
import { Clock, Medal } from "lucide-react";
import { Exam } from "@/lib/types";

interface ExamCardProps {
  exam: Exam;
}

const ExamCard = ({ exam }: ExamCardProps) => {
  const {
    id,
    title,
    description,
    duration,
    questionCount,
    difficulty,
    successRate,
    categoryId
  } = exam;

  // Determine difficulty color and icon
  let difficultyColor = "text-accent";
  let difficultyBg = "bg-accent/10";
  
  if (difficulty === "Advanced") {
    difficultyColor = "text-warning";
    difficultyBg = "bg-warning/10";
  } else if (difficulty === "Beginner-Friendly") {
    difficultyColor = "text-success";
    difficultyBg = "bg-success/10";
  }

  // Truncate description if it's too long
  const truncatedDescription = description.length > 100
    ? `${description.substring(0, 100)}...`
    : description;

  return (
    <Link href={`/exams/${id}`}>
      <div className="border border-neutral-200 rounded-lg p-6 hover:border-primary transition-colors cursor-pointer">
        <div className="flex justify-between items-start mb-4">
          <div>
            <span className="px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded">
              {categoryId === 1 ? "Software Engineering" : 
               categoryId === 2 ? "Data Science" : 
               categoryId === 3 ? "Product Management" : "UX/UI Design"}
            </span>
          </div>
          <span className="text-sm font-medium text-neutral-700">{questionCount} questions</span>
        </div>
        <h3 className="font-bold text-lg mb-2">{title}</h3>
        <p className="text-neutral-700 text-sm mb-4">{truncatedDescription}</p>
        <div className="flex items-center text-sm text-neutral-700 mb-6">
          <Clock className="mr-2 h-4 w-4" />
          <span>{duration} minutes</span>
          <span className="mx-2">•</span>
          <Medal className={`mr-2 h-4 w-4 ${difficultyColor}`} />
          <span>{difficulty}</span>
        </div>
        <div className="flex items-center">
          <span className="text-sm font-medium mr-2">Success rate:</span>
          <div className="w-32 h-2 bg-neutral-200 rounded-full">
            <div 
              className={`h-2 ${
                successRate < 40 ? "bg-warning" : 
                successRate < 60 ? "bg-accent" : "bg-success"
              } rounded-full`} 
              style={{ width: `${successRate}%` }}
            />
          </div>
          <span className="ml-2 text-sm">{successRate}%</span>
        </div>
      </div>
    </Link>
  );
};

export default ExamCard;
