import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { 
  Question,
  Option,
  Exam,
  CategoryScore
} from "@/lib/types";
import {
  Clock,
  Flag,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface ExamInterfaceProps {
  exam: Exam;
  questions: (Question & { options: Option[] })[];
  paperId?: number;
}

type QuestionStatus = "not-visited" | "current" | "answered" | "skipped" | "flagged";

const ExamInterface = ({ exam, questions, paperId = 0 }: ExamInterfaceProps) => {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Adjust for different exam papers
  const paperDurationMultiplier = paperId === 1 ? 0.8 : paperId === 2 ? 0.85 : 1;
  const paperQuestionMultiplier = paperId === 1 ? 0.7 : paperId === 2 ? 0.75 : 1;
  
  // Filter questions for practice papers
  const examQuestions = paperId > 0
    ? questions.slice(0, Math.floor(questions.length * paperQuestionMultiplier))
    : questions;
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number | null>>({});
  const [questionStatuses, setQuestionStatuses] = useState<Record<number, QuestionStatus>>({});
  const [remainingTime, setRemainingTime] = useState(Math.floor(exam.duration * 60 * paperDurationMultiplier)); // in seconds
  const [examStartTime] = useState(Date.now());
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize question statuses
  useEffect(() => {
    const initialStatuses: Record<number, QuestionStatus> = {};
    examQuestions.forEach((q, index) => {
      if (index === 0) {
        initialStatuses[q.id] = "current";
      } else {
        initialStatuses[q.id] = "not-visited";
      }
    });
    setQuestionStatuses(initialStatuses);
  }, [examQuestions]);

  // Timer functionality
  useEffect(() => {
    const timerInterval = setInterval(() => {
      setRemainingTime(prev => {
        if (prev <= 0) {
          clearInterval(timerInterval);
          submitExam();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timerInterval);
  }, []);

  const formatTime = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    return [
      hours.toString().padStart(2, "0"),
      minutes.toString().padStart(2, "0"),
      secs.toString().padStart(2, "0")
    ].join(":");
  };

  const selectAnswer = (questionId: number, optionId: number) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: optionId
    }));

    setQuestionStatuses(prev => ({
      ...prev,
      [questionId]: "answered"
    }));
  };

  const navigateToQuestion = (index: number) => {
    if (index >= 0 && index < examQuestions.length) {
      const currentQuestionId = examQuestions[currentQuestionIndex].id;
      const newQuestionId = examQuestions[index].id;
      
      // Update status of current question if needed
      if (questionStatuses[currentQuestionId] === "current") {
        setQuestionStatuses(prev => ({
          ...prev,
          [currentQuestionId]: answers[currentQuestionId] != null ? "answered" : "skipped"
        }));
      }
      
      // Set new question as current
      setQuestionStatuses(prev => ({
        ...prev,
        [newQuestionId]: "current"
      }));
      
      setCurrentQuestionIndex(index);
    }
  };

  const nextQuestion = () => {
    navigateToQuestion(currentQuestionIndex + 1);
  };

  const previousQuestion = () => {
    navigateToQuestion(currentQuestionIndex - 1);
  };

  const toggleFlagQuestion = () => {
    const questionId = examQuestions[currentQuestionIndex].id;
    
    setQuestionStatuses(prev => ({
      ...prev,
      [questionId]: prev[questionId] === "flagged" ? 
        (answers[questionId] != null ? "answered" : "current") : 
        "flagged"
    }));
  };

  const calculateScore = () => {
    let score = 0;
    const categoryScores: Record<string, { score: number, total: number }> = {};
    
    examQuestions.forEach(question => {
      const answered = answers[question.id];
      const correctOption = question.options.find(option => option.isCorrect);
      
      // Initialize category if not exists
      if (!categoryScores[question.category]) {
        categoryScores[question.category] = { score: 0, total: 0 };
      }
      
      categoryScores[question.category].total += 1;
      
      if (answered != null && correctOption && answered === correctOption.id) {
        score += 1;
        categoryScores[question.category].score += 1;
      }
    });
    
    // Calculate category scores for API
    const categoryScoresArray: Omit<CategoryScore, "id" | "resultId">[] = 
      Object.entries(categoryScores).map(([category, data]) => ({
        category,
        score: data.score,
        maxScore: data.total,
        percentage: Math.round((data.score / data.total) * 100)
      }));
    
    return {
      score,
      maxScore: examQuestions.length,
      percentage: (score / examQuestions.length) * 100,
      passed: (score / examQuestions.length) * 100 >= exam.passPercentage,
      timeSpent: Math.round((Date.now() - examStartTime) / 1000),
      categoryScores: categoryScoresArray
    };
  };

  const submitExam = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to submit this exam",
        variant: "destructive"
      });
      return;
    }

    try {
      setIsSubmitting(true);
      
      const results = calculateScore();
      
      const response = await apiRequest("POST", `/api/users/${user.id}/exam-results`, {
        examId: exam.id,
        score: results.score,
        maxScore: results.maxScore,
        passed: results.passed,
        timeSpent: results.timeSpent,
        categoryScores: results.categoryScores
      });
      
      const resultId = response.id;
      
      setLocation(`/exams/${exam.id}/results/${resultId}`);
    } catch (error) {
      toast({
        title: "Failed to submit exam",
        description: "There was an error submitting your exam results",
        variant: "destructive"
      });
      setIsSubmitting(false);
    }
  };

  const confirmEndExam = () => {
    if (confirm("Are you sure you want to end the exam? This action cannot be undone.")) {
      submitExam();
    }
  };

  // Current question
  const currentQuestion = examQuestions[currentQuestionIndex];

  return (
    <div className="bg-white rounded-lg shadow-md">
      <div className="border-b border-neutral-200 p-4 flex justify-between items-center">
        <h1 className="font-bold text-lg md:text-xl">{exam.title}</h1>
        <div className="flex items-center">
          <div className="bg-primary/10 text-primary px-3 py-2 rounded-lg font-medium exam-timer animate-pulse">
            <Clock className="inline-block mr-1 h-4 w-4" />
            <span>{formatTime(remainingTime)}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4">
        <div className="lg:col-span-3 p-6">
          <div className="mb-6">
            <div className="flex justify-between mb-4">
              <div>
                <span className="font-medium">Question {currentQuestionIndex + 1} of {examQuestions.length}</span>
                <span className="ml-2 text-xs px-2 py-0.5 bg-secondary/10 text-secondary rounded-full">
                  {currentQuestion.category}
                </span>
              </div>
              <div>
                <button
                  onClick={toggleFlagQuestion}
                  className="text-primary hover:underline text-sm flex items-center"
                >
                  <Flag className="h-4 w-4 mr-1" />
                  Flag for review
                </button>
              </div>
            </div>
            
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-3">{currentQuestion.question}</h2>
              {currentQuestion.code && (
                <div className="bg-neutral-100 p-4 rounded-lg mb-4 font-mono text-sm whitespace-pre-wrap">
                  {currentQuestion.code}
                </div>
              )}
            </div>
            
            <div className="space-y-3">
              {currentQuestion.options.map(option => (
                <div
                  key={option.id}
                  className={`border rounded-lg p-4 hover:bg-neutral-50 cursor-pointer ${
                    answers[currentQuestion.id] === option.id ? 'border-primary bg-primary/5' : 'border-neutral-200'
                  }`}
                  onClick={() => selectAnswer(currentQuestion.id, option.id)}
                >
                  <div className="flex items-center">
                    <div className={`h-5 w-5 rounded-full mr-3 flex-shrink-0 ${
                      answers[currentQuestion.id] === option.id 
                        ? 'border-2 border-primary bg-primary/20' 
                        : 'border border-neutral-400'
                    }`}></div>
                    <div>
                      <p>{option.text}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={previousQuestion}
              disabled={currentQuestionIndex === 0}
            >
              <ChevronLeft className="mr-1 h-4 w-4" />
              Previous
            </Button>
            {currentQuestionIndex === examQuestions.length - 1 ? (
              <Button onClick={submitExam} disabled={isSubmitting}>
                {isSubmitting ? "Submitting..." : "Submit Exam"}
              </Button>
            ) : (
              <Button onClick={nextQuestion}>
                Next Question
                <ChevronRight className="ml-1 h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
        
        <div className="border-l border-neutral-200 p-4 hidden lg:block">
          <h3 className="font-medium mb-3">Question Navigator</h3>
          <div className="grid grid-cols-5 gap-2 mb-6">
            {examQuestions.map((question, index) => {
              let bgClass = "bg-neutral-100 text-neutral-700";
              
              switch (questionStatuses[question.id]) {
                case "current":
                  bgClass = "bg-primary text-white font-medium";
                  break;
                case "answered":
                  bgClass = "bg-success/10 text-success font-medium";
                  break;
                case "skipped":
                  bgClass = "bg-error/10 text-error font-medium";
                  break;
                case "flagged":
                  bgClass = "bg-warning/10 text-warning font-medium";
                  break;
                default:
                  bgClass = "bg-neutral-100 text-neutral-700";
              }
              
              return (
                <button
                  key={question.id}
                  className={`h-10 w-10 flex items-center justify-center rounded-lg text-sm cursor-pointer ${bgClass}`}
                  onClick={() => navigateToQuestion(index)}
                >
                  {index + 1}
                </button>
              );
            })}
            {examQuestions.length > 15 && <div className="h-10 w-10 flex items-center justify-center text-sm">...</div>}
          </div>
          
          <div className="mb-6">
            <h3 className="font-medium mb-2">Legend</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center">
                <div className="h-4 w-4 bg-primary rounded mr-2"></div>
                <span>Current Question</span>
              </div>
              <div className="flex items-center">
                <div className="h-4 w-4 bg-success/10 text-success rounded mr-2"></div>
                <span>Answered</span>
              </div>
              <div className="flex items-center">
                <div className="h-4 w-4 bg-error/10 text-error rounded mr-2"></div>
                <span>Skipped</span>
              </div>
              <div className="flex items-center">
                <div className="h-4 w-4 bg-warning/10 text-warning rounded mr-2"></div>
                <span>Flagged for Review</span>
              </div>
              <div className="flex items-center">
                <div className="h-4 w-4 bg-neutral-100 rounded mr-2"></div>
                <span>Not Visited</span>
              </div>
            </div>
          </div>
          
          <div>
            <Button
              variant="destructive"
              className="w-full"
              onClick={confirmEndExam}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Submitting..." : "End Exam"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExamInterface;
