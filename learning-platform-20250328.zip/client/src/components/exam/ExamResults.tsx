import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  ExamResult,
  CategoryScore,
  Exam
} from "@/lib/types";
import {
  Download,
  Book,
  Code,
  FileText,
  Users,
  ExternalLink,
  AlertCircle
} from "lucide-react";

interface ExamResultsProps {
  result: ExamResult & { 
    exam: Exam;
    categoryScores: CategoryScore[];
  };
}

const ExamResults = ({ result }: ExamResultsProps) => {
  const { score, maxScore, passed, completedAt, exam, categoryScores } = result;
  const percentage = Math.round((score / maxScore) * 100);
  
  // Find areas to improve (categories with score less than 70%)
  const areasToImprove = categoryScores
    .filter(cs => cs.percentage < 70)
    .sort((a, b) => a.percentage - b.percentage);

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
      <div className="bg-primary/10 border-b border-primary/20 p-6 text-center">
        <h1 className="text-2xl font-bold mb-2">Exam Results</h1>
        <p className="text-neutral-700">{exam.title}</p>
      </div>
      
      <div className="p-6">
        <div className="flex flex-col md:flex-row justify-between mb-8">
          <div className="mb-4 md:mb-0">
            <h2 className="text-lg font-medium mb-2">Performance Summary</h2>
            <div className="flex items-center">
              <div className="text-4xl font-bold text-primary mr-3">{score}/{maxScore}</div>
              <div>
                <div className="font-medium">{percentage}% Score</div>
                <div className="text-sm text-neutral-600">
                  Completed on {new Date(completedAt).toLocaleDateString()}
                </div>
              </div>
            </div>
          </div>
          
          <div className={`${
            passed ? 'bg-success/10 border-success/20' : 'bg-error/10 border-error/20'
          } border rounded-lg p-4 text-center`}>
            <div className={`${
              passed ? 'text-success' : 'text-error'
            } font-bold text-lg mb-1`}>
              {passed ? 'PASSED' : 'FAILED'}
            </div>
            <p className="text-sm">Minimum passing score: {exam.passPercentage}%</p>
          </div>
        </div>
        
        <div className="mb-8">
          <h2 className="text-lg font-medium mb-4">Performance by Category</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {categoryScores.map((cs) => (
              <div key={cs.category} className="border border-neutral-200 rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium">{cs.category}</h3>
                  <span className={`${
                    cs.percentage >= 80 ? 'text-success' :
                    cs.percentage >= 60 ? 'text-primary' : 'text-warning'
                  } font-medium`}>{cs.percentage}%</span>
                </div>
                <div className="w-full h-2 bg-neutral-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${
                      cs.percentage >= 80 ? 'bg-success' :
                      cs.percentage >= 60 ? 'bg-primary' : 'bg-warning'
                    } rounded-full`} 
                    style={{ width: `${cs.percentage}%` }}
                  ></div>
                </div>
                <div className="text-sm text-neutral-600 mt-2">
                  {cs.score}/{cs.maxScore} questions correct
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {areasToImprove.length > 0 && (
          <div className="mb-8">
            <h2 className="text-lg font-medium mb-4">Areas to Improve</h2>
            {areasToImprove.map((area) => (
              <div key={area.category} className="bg-warning/10 border border-warning/20 rounded-lg p-4 mb-4">
                <h3 className="font-medium flex items-center mb-2">
                  <AlertCircle className="text-warning mr-2 h-5 w-5" />
                  {area.category}
                </h3>
                <p className="text-sm text-neutral-700 mb-2">
                  You missed {area.maxScore - area.score} out of {area.maxScore} questions in this category.
                </p>
                <a href="#" className="text-primary text-sm font-medium hover:underline flex items-center">
                  Review recommended resources
                  <ExternalLink className="ml-1 h-3 w-3" />
                </a>
              </div>
            ))}
          </div>
        )}
        
        <div className="mb-8">
          <h2 className="text-lg font-medium mb-4">Recommended Next Steps</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <a href="#" className="border border-neutral-200 rounded-lg p-4 hover:border-primary hover:shadow-sm transition-all">
              <div className="flex items-start">
                <div className="bg-primary/10 p-2 rounded-lg mr-3">
                  <Book className="text-primary h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-medium mb-1">System Design Fundamentals</h3>
                  <p className="text-sm text-neutral-700">A deep dive into scalability patterns for distributed systems.</p>
                </div>
              </div>
            </a>
            
            <a href="#" className="border border-neutral-200 rounded-lg p-4 hover:border-primary hover:shadow-sm transition-all">
              <div className="flex items-start">
                <div className="bg-primary/10 p-2 rounded-lg mr-3">
                  <Code className="text-primary h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-medium mb-1">Dynamic Programming Workshop</h3>
                  <p className="text-sm text-neutral-700">Interactive exercises to master DP concepts and patterns.</p>
                </div>
              </div>
            </a>
            
            <a href="#" className="border border-neutral-200 rounded-lg p-4 hover:border-primary hover:shadow-sm transition-all">
              <div className="flex items-start">
                <div className="bg-primary/10 p-2 rounded-lg mr-3">
                  <FileText className="text-primary h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-medium mb-1">Practice Exam: Advanced System Design</h3>
                  <p className="text-sm text-neutral-700">Focused practice on system design scenarios.</p>
                </div>
              </div>
            </a>
            
            <a href="#" className="border border-neutral-200 rounded-lg p-4 hover:border-primary hover:shadow-sm transition-all">
              <div className="flex items-start">
                <div className="bg-primary/10 p-2 rounded-lg mr-3">
                  <Users className="text-primary h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-medium mb-1">Mock Interview Session</h3>
                  <p className="text-sm text-neutral-700">Practice with an experienced interviewer from Google.</p>
                </div>
              </div>
            </a>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row justify-between">
          <Button variant="outline" className="mb-3 md:mb-0">
            <Download className="mr-2 h-4 w-4" />
            Export Results
          </Button>
          <div className="flex space-x-3">
            <Button variant="outline" asChild>
              <Link href={`/exams/${exam.id}`}>
                Review Answers
              </Link>
            </Button>
            <Button asChild>
              <Link href="/dashboard">
                Return to Dashboard
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExamResults;
