import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Exam } from "@/lib/types";
import ExamCard from "@/components/exam/ExamCard";

const ExamsSection = () => {
  const { data: exams, isLoading, error } = useQuery({
    queryKey: ['/api/exams'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  if (isLoading) {
    return (
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold">Practice Exams</h2>
            <Link href="/exams" className="text-primary font-medium hover:underline">
              View All
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="border border-neutral-200 rounded-lg p-6 animate-pulse">
                <div className="flex justify-between items-start mb-4">
                  <div className="h-6 w-32 bg-neutral-200 rounded"></div>
                  <div className="h-4 w-24 bg-neutral-200 rounded"></div>
                </div>
                <div className="h-6 bg-neutral-200 rounded mb-2"></div>
                <div className="h-4 bg-neutral-200 rounded mb-2"></div>
                <div className="h-4 bg-neutral-200 rounded w-3/4 mb-4"></div>
                <div className="flex items-center mb-6">
                  <div className="h-4 w-24 bg-neutral-200 rounded mr-4"></div>
                  <div className="h-4 w-24 bg-neutral-200 rounded"></div>
                </div>
                <div className="h-4 bg-neutral-200 rounded"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold">Practice Exams</h2>
            <Link href="/exams" className="text-primary font-medium hover:underline">
              View All
            </Link>
          </div>
          <div className="text-center text-red-500 py-8">
            Error loading exams. Please try again later.
          </div>
        </div>
      </section>
    );
  }

  // Display top 3 exams
  const displayExams = exams.slice(0, 3);

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold">Practice Exams</h2>
          <Link href="/exams" className="text-primary font-medium hover:underline">
            View All
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayExams.map((exam: Exam) => (
            <ExamCard key={exam.id} exam={exam} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExamsSection;
