import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Category } from "@/lib/types";
import { Code, ChartLine, Users, Paintbrush, BarChart, Database } from "lucide-react";

const CategoryIcon = ({ icon }: { icon: string }) => {
  switch (icon) {
    case "fa-code":
      return <Code className="text-primary text-2xl" />;
    case "fa-chart-line":
      return <ChartLine className="text-secondary text-2xl" />;
    case "fa-database":
      return <Database className="text-secondary text-2xl" />;
    case "fa-bar-chart":
      return <BarChart className="text-secondary text-2xl" />;
    case "fa-users-cog":
      return <Users className="text-[#00CC99] text-2xl" />;
    case "fa-paint-brush":
      return <Paintbrush className="text-[#F59E0B] text-2xl" />;
    default:
      return <Code className="text-primary text-2xl" />;
  }
};

const CategoryCard = ({ category }: { category: Category }) => {
  let bgColorClass = "bg-primary/10";
  
  switch (category.colorScheme) {
    case "primary":
      bgColorClass = "bg-primary/10";
      break;
    case "secondary":
      bgColorClass = "bg-secondary/10";
      break;
    case "accent":
      bgColorClass = "bg-[#00CC99]/10";
      break;
    case "warning":
      bgColorClass = "bg-[#F59E0B]/10";
      break;
    default:
      bgColorClass = "bg-primary/10";
  }

  return (
    <Link href={`/courses?category=${category.id}`}>
      <div className="bg-neutral-100 rounded-xl p-6 text-center hover:shadow-md transition-shadow cursor-pointer">
        <div className={`${bgColorClass} w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center`}>
          <CategoryIcon icon={category.icon} />
        </div>
        <h3 className="font-semibold mb-1">{category.name}</h3>
        <p className="text-sm text-neutral-700">{category.courseCount} courses</p>
      </div>
    </Link>
  );
};

const FeaturedCategories = () => {
  const { data: categories, isLoading, error } = useQuery({
    queryKey: ['/api/categories'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  if (isLoading) {
    return (
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Popular Career Paths</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-neutral-100 rounded-xl p-6 animate-pulse">
                <div className="bg-neutral-200 w-16 h-16 mx-auto mb-4 rounded-full"></div>
                <div className="h-6 bg-neutral-200 rounded mb-2"></div>
                <div className="h-4 w-24 mx-auto bg-neutral-200 rounded"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Popular Career Paths</h2>
          <div className="text-center text-red-500">
            Error loading categories. Please try again later.
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">Popular Career Paths</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {categories.map((category: Category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCategories;
