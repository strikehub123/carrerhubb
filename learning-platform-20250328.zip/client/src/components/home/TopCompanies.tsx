import React from "react";
import { 
  SiGoogle, 
  SiMsi, 
  SiAmazon, 
  SiApple, 
  SiMeta, 
  SiNetflix, 
  SiUber, 
  SiAirbnb, 
  SiTesla, 
  SiX 
} from "react-icons/si";

const TopCompanies = () => {
  const companies = [
    { 
      name: "Google", 
      icon: <SiGoogle className="h-10 w-10 text-blue-500" />,
      color: "hover:text-blue-500" 
    },
    { 
      name: "Microsoft", 
      icon: <SiMsi className="h-10 w-10 text-blue-600" />,
      color: "hover:text-blue-600" 
    },
    { 
      name: "Amazon", 
      icon: <SiAmazon className="h-10 w-10 text-yellow-500" />,
      color: "hover:text-yellow-500" 
    },
    { 
      name: "Apple", 
      icon: <SiApple className="h-10 w-10 text-gray-800" />,
      color: "hover:text-gray-800" 
    },
    { 
      name: "Meta", 
      icon: <SiMeta className="h-10 w-10 text-blue-700" />,
      color: "hover:text-blue-700" 
    },
    { 
      name: "Netflix", 
      icon: <SiNetflix className="h-10 w-10 text-red-600" />,
      color: "hover:text-red-600" 
    },
    { 
      name: "Uber", 
      icon: <SiUber className="h-10 w-10 text-gray-900" />,
      color: "hover:text-gray-900" 
    },
    { 
      name: "Airbnb", 
      icon: <SiAirbnb className="h-10 w-10 text-red-500" />,
      color: "hover:text-red-500" 
    },
    { 
      name: "Tesla", 
      icon: <SiTesla className="h-10 w-10 text-red-600" />,
      color: "hover:text-red-600" 
    },
    { 
      name: "Twitter (X)", 
      icon: <SiX className="h-10 w-10 text-gray-800" />,
      color: "hover:text-gray-800" 
    }
  ];

  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Dream Placement Companies</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Our students have been placed at these top tech companies. Prepare with our courses and exams to land your dream job.
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          {companies.map((company) => (
            <div 
              key={company.name} 
              className={`flex flex-col items-center justify-center p-4 rounded-lg hover:bg-white hover:shadow-md transition-all duration-300 ${company.color} cursor-pointer`}
            >
              {company.icon}
              <span className="mt-2 font-medium">{company.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TopCompanies;