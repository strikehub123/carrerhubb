import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const Hero = () => {
  return (
    <section className="bg-gradient-to-r from-primary to-primary/80 text-white py-12 md:py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-3xl md:text-5xl font-bold mb-4">
            Prepare for Your Dream Career
          </h1>
          <p className="text-xl md:text-2xl opacity-90 mb-8">
            Master the skills, ace the interviews, and land your dream job with our specialized courses and practice exams.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button
              asChild
              size="lg"
              variant="outline"
              className="bg-white text-primary border-white hover:bg-white/90 hover:text-primary"
            >
              <Link href="/courses">Explore Courses</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="secondary"
            >
              <Link href="/exams">Take Practice Exams</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
