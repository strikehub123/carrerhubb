import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/lib/auth";
import { UserProgress } from "@/lib/types";

const ContinueLearning = () => {
  const { user } = useAuth();

  const { data: progressData, isLoading, error } = useQuery({
    queryKey: [`/api/users/${user?.id}/progress`],
    enabled: !!user,
    staleTime: 60 * 1000, // 1 minute
  });

  if (isLoading) {
    return (
      <div className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <div className="h-7 w-48 bg-neutral-200 rounded"></div>
          <div className="h-5 w-24 bg-neutral-200 rounded"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="bg-white rounded-lg shadow-sm overflow-hidden animate-pulse"
            >
              <div className="w-full h-40 bg-neutral-200"></div>
              <div className="p-4">
                <div className="h-6 bg-neutral-200 rounded mb-3"></div>
                <div className="flex justify-between items-center mb-3">
                  <div className="h-4 w-32 bg-neutral-200 rounded"></div>
                  <div className="h-4 w-12 bg-neutral-200 rounded"></div>
                </div>
                <div className="w-full h-1.5 bg-neutral-200 rounded-full mb-4"></div>
                <div className="h-5 w-40 bg-neutral-200 rounded"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error || !progressData) {
    return (
      <div className="mb-8">
        <h2 className="text-xl font-bold mb-4">Continue Learning</h2>
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <p className="text-neutral-700">
            Unable to load your courses. Please try again later.
          </p>
        </div>
      </div>
    );
  }

  // If user has no courses in progress
  if (progressData.length === 0) {
    return (
      <div className="mb-8">
        <h2 className="text-xl font-bold mb-4">Continue Learning</h2>
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <p className="text-neutral-700">
            You don't have any courses in progress. 
            <Link href="/courses" className="text-primary font-medium ml-1 hover:underline">
              Explore our courses
            </Link>
            to start learning!
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Continue Learning</h2>
        <Link
          href="/courses"
          className="text-primary font-medium hover:underline"
        >
          View All Courses
        </Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {progressData.slice(0, 3).map((progress: UserProgress) => {
          const completionPercentage = Math.round(
            (progress.completedLessons / progress.totalLessons) * 100
          );
          
          // Default values in case course information isn't loaded
          const courseTitle = progress.course?.title || "Course";
          const courseImage = progress.course?.imageUrl || "https://via.placeholder.com/800x400?text=Course+Image";
          
          return (
            <div
              key={progress.id}
              className="bg-white rounded-lg shadow-sm overflow-hidden"
            >
              <div className="relative">
                <img
                  src={courseImage}
                  alt={courseTitle}
                  className="w-full h-40 object-cover"
                />
                <div className="absolute top-0 right-0 m-3">
                  <span className="bg-primary text-white text-xs font-medium px-2 py-1 rounded">
                    IN PROGRESS
                  </span>
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-1">{courseTitle}</h3>
                <div className="flex justify-between items-center mb-3">
                  <span className="text-sm text-neutral-700">
                    {progress.completedLessons} of {progress.totalLessons} lessons completed
                  </span>
                  <span className="text-sm font-medium">{completionPercentage}%</span>
                </div>
                <div className="w-full h-1.5 bg-neutral-200 rounded-full mb-4">
                  <div
                    className="h-full bg-primary rounded-full"
                    style={{ width: `${completionPercentage}%` }}
                  ></div>
                </div>
                <Link
                  href={`/courses/${progress.courseId}`}
                  className="text-primary font-medium text-sm hover:underline"
                >
                  Continue Learning →
                </Link>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ContinueLearning;
