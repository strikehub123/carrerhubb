import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { UserProgress } from "@/lib/types";
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";

const ProgressSummary = () => {
  const { user } = useAuth();

  const { data: progressData, isLoading, error } = useQuery({
    queryKey: [`/api/users/${user?.id}/progress`],
    enabled: !!user,
    staleTime: 60 * 1000, // 1 minute
  });

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
        <div className="flex justify-between items-start mb-4">
          <div className="h-6 w-32 bg-neutral-200 rounded"></div>
          <div className="h-4 w-24 bg-neutral-200 rounded"></div>
        </div>
        <div className="flex items-center mb-4">
          <div className="w-16 h-16 rounded-full bg-neutral-200"></div>
          <div className="ml-4">
            <div className="h-4 w-40 bg-neutral-200 rounded mb-2"></div>
            <div className="h-5 w-32 bg-neutral-200 rounded"></div>
          </div>
        </div>
        <div className="space-y-3">
          <div className="h-4 w-full bg-neutral-200 rounded"></div>
          <div className="h-4 w-full bg-neutral-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (error || !progressData) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="font-semibold mb-2">Your Progress</h2>
        <p className="text-sm text-neutral-600">
          Unable to load progress data. Please try again later.
        </p>
      </div>
    );
  }

  // If user has no progress data yet
  if (progressData.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="font-semibold mb-2">Your Progress</h2>
        <p className="text-sm text-neutral-600">
          You haven't enrolled in any courses yet. Explore our courses to start learning!
        </p>
      </div>
    );
  }

  // Calculate overall completion
  const totalCompletedLessons = progressData.reduce(
    (sum: number, item: UserProgress) => sum + item.completedLessons,
    0
  );
  const totalLessons = progressData.reduce(
    (sum: number, item: UserProgress) => sum + item.totalLessons,
    0
  );
  const completionPercentage = Math.round(
    (totalCompletedLessons / totalLessons) * 100
  );

  // Calculate study hours (approximation based on completed lessons)
  const studyHours = (totalCompletedLessons * 15) / 60; // Assuming each lesson takes ~15 minutes

  // For the pie chart
  const chartData = [
    { name: "Completed", value: completionPercentage },
    { name: "Remaining", value: 100 - completionPercentage },
  ];
  const COLORS = ["#3366CC", "#E5E9F2"];

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex justify-between items-start mb-4">
        <h2 className="font-semibold">Your Progress</h2>
        <span className="text-xs px-2 py-1 bg-primary/10 text-primary rounded-full">
          Last 30 days
        </span>
      </div>
      <div className="flex items-center mb-4">
        <div className="w-16 h-16 flex-shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={18}
                outerRadius={32}
                paddingAngle={2}
                dataKey="value"
                strokeWidth={0}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="ml-4">
          <div className="text-sm text-neutral-700 mb-1">Course Completion</div>
          <div className="font-medium">
            {progressData.length} of {progressData.length} courses in progress
          </div>
        </div>
      </div>
      <div className="space-y-3">
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span>Study hours</span>
            <span className="font-medium">{studyHours.toFixed(1)} hrs</span>
          </div>
          <div className="w-full h-2 bg-neutral-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full"
              style={{ width: `${Math.min((studyHours / 30) * 100, 100)}%` }}
            ></div>
          </div>
        </div>
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span>Overall progress</span>
            <span className="font-medium">
              {totalCompletedLessons} of {totalLessons} lessons
            </span>
          </div>
          <div className="w-full h-2 bg-neutral-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-secondary rounded-full"
              style={{ width: `${completionPercentage}%` }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgressSummary;
