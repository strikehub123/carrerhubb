import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Exam } from "@/lib/types";

const RecommendedExams = () => {
  const { data: exams, isLoading, error } = useQuery({
    queryKey: ['/api/exams'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  if (isLoading) {
    return (
      <div>
        <div className="flex justify-between items-center mb-6">
          <div className="h-7 w-48 bg-neutral-200 rounded"></div>
          <div className="h-5 w-24 bg-neutral-200 rounded"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-pulse">
          {[...Array(2)].map((_, i) => (
            <div
              key={i}
              className="bg-white rounded-lg shadow-sm p-5 border-l-4 border-primary"
            >
              <div className="flex justify-between items-start mb-3">
                <div className="h-6 w-40 bg-neutral-200 rounded"></div>
                <div className="h-5 w-20 bg-neutral-200 rounded"></div>
              </div>
              <div className="h-16 bg-neutral-200 rounded mb-4"></div>
              <div className="flex items-center mb-4">
                <div className="h-4 w-24 bg-neutral-200 rounded mr-4"></div>
                <div className="h-4 w-24 bg-neutral-200 rounded"></div>
              </div>
              <div className="h-10 w-full bg-neutral-200 rounded"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error || !exams) {
    return (
      <div>
        <h2 className="text-xl font-bold mb-4">Recommended Exams</h2>
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <p className="text-neutral-700">
            Unable to load recommended exams. Please try again later.
          </p>
        </div>
      </div>
    );
  }

  // Sort exams by difficulty (easier ones first to build confidence)
  const sortedExams = [...exams].sort((a: Exam, b: Exam) => {
    const difficultyRank = {
      "Beginner-Friendly": 1,
      "Intermediate": 2,
      "Advanced": 3
    };
    return difficultyRank[a.difficulty as keyof typeof difficultyRank] - 
           difficultyRank[b.difficulty as keyof typeof difficultyRank];
  });

  // Get top 2 recommended exams
  const recommendedExams = sortedExams.slice(0, 2);

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Recommended Exams</h2>
        <Link href="/exams" className="text-primary font-medium hover:underline">
          View All Exams
        </Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {recommendedExams.map((exam: Exam) => {
          const isPriority = exam.difficulty === "Advanced";
          
          return (
            <div 
              key={exam.id}
              className={`bg-white rounded-lg shadow-sm p-5 border-l-4 ${
                isPriority ? 'border-primary' : 'border-secondary'
              }`}
            >
              <div className="flex justify-between items-start mb-3">
                <h3 className="font-bold">{exam.title}</h3>
                <span className={`${
                  isPriority 
                    ? 'bg-primary/10 text-primary' 
                    : 'bg-secondary/10 text-secondary'
                } text-xs font-medium px-2 py-1 rounded`}>
                  {isPriority ? 'High Priority' : 'Recommended'}
                </span>
              </div>
              <p className="text-sm text-neutral-700 mb-4">{exam.description}</p>
              <div className="flex items-center text-sm text-neutral-700 mb-4">
                <span className="flex items-center mr-4">
                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  {exam.duration} minutes
                </span>
                <span className="flex items-center">
                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  {exam.questionCount} questions
                </span>
              </div>
              <Button 
                className="w-full" 
                variant={isPriority ? "default" : "secondary"} 
                asChild
              >
                <Link href={`/exams/${exam.id}`}>
                  Start Exam
                </Link>
              </Button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RecommendedExams;
