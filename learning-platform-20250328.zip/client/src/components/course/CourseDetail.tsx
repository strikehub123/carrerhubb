import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import {
  Module,
  Lesson,
  Course
} from "@/lib/types";
import {
  Star,
  Clock,
  Users,
  Check,
  ChevronDown,
  ChevronUp,
  PlayCircle,
  FileText,
  Video,
  File,
  Award,
  Share2,
  Linkedin,
  Twitter,
  Facebook,
  Mail
} from "lucide-react";
import { formatDuration } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";

interface CourseDetailProps {
  course: Course;
  modules: Module[];
  lessonsMap: Record<number, Lesson[]>;
}

const CourseDetail = ({ course, modules, lessonsMap }: CourseDetailProps) => {
  const [expandedModules, setExpandedModules] = useState<Record<number, boolean>>({});
  const { user } = useAuth();
  const { toast } = useToast();

  const toggleModule = (moduleId: number) => {
    setExpandedModules(prev => ({
      ...prev,
      [moduleId]: !prev[moduleId]
    }));
  };

  const handleEnroll = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to enroll in this course",
        variant: "destructive"
      });
      return;
    }

    try {
      // Calculate total lessons
      const totalLessons = modules.reduce((total, module) => {
        return total + (lessonsMap[module.id]?.length || 0);
      }, 0);

      // Create progress record
      await apiRequest("POST", `/api/users/${user.id}/progress`, {
        courseId: course.id,
        completedLessons: 0,
        totalLessons
      });

      toast({
        title: "Successfully enrolled!",
        description: "You can now access the course content",
        variant: "default"
      });
    } catch (error) {
      toast({
        title: "Failed to enroll",
        description: "There was an error enrolling you in the course",
        variant: "destructive"
      });
    }
  };

  const handleAddToWishlist = () => {
    toast({
      title: "Added to wishlist",
      description: "This course has been added to your wishlist",
      variant: "default"
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="relative">
        <img 
          src={course.imageUrl} 
          alt={course.title} 
          className="w-full h-64 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
          <div className="p-6 text-white">
            <div className="mb-2">
              <span className="px-2 py-1 bg-primary/80 text-white text-xs font-medium rounded">
                {course.difficulty}
              </span>
            </div>
            <h1 className="text-3xl font-bold mb-2">{course.title}</h1>
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <Star className="h-4 w-4 text-[#F59E0B] fill-[#F59E0B]" />
                <span className="ml-1">{course.rating.toFixed(1)} ({course.ratingCount} reviews)</span>
              </div>
              <div className="flex items-center">
                <Users className="h-4 w-4" />
                <span className="ml-1">1,254 students</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4" />
                <span className="ml-1">{formatDuration(course.duration)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 p-6">
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4">About This Course</h2>
            <p className="text-neutral-700 mb-4">{course.description}</p>
          </div>

          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4">What You'll Learn</h2>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <li className="flex items-start">
                <Check className="text-green-500 mt-1 mr-2 h-5 w-5" />
                <span>Design principles for scalable systems</span>
              </li>
              <li className="flex items-start">
                <Check className="text-green-500 mt-1 mr-2 h-5 w-5" />
                <span>Database selection and optimization</span>
              </li>
              <li className="flex items-start">
                <Check className="text-green-500 mt-1 mr-2 h-5 w-5" />
                <span>Caching strategies and implementations</span>
              </li>
              <li className="flex items-start">
                <Check className="text-green-500 mt-1 mr-2 h-5 w-5" />
                <span>Load balancing and traffic management</span>
              </li>
              <li className="flex items-start">
                <Check className="text-green-500 mt-1 mr-2 h-5 w-5" />
                <span>Microservices architecture</span>
              </li>
              <li className="flex items-start">
                <Check className="text-green-500 mt-1 mr-2 h-5 w-5" />
                <span>API design best practices</span>
              </li>
              <li className="flex items-start">
                <Check className="text-green-500 mt-1 mr-2 h-5 w-5" />
                <span>Real-world case studies from FAANG interviews</span>
              </li>
              <li className="flex items-start">
                <Check className="text-green-500 mt-1 mr-2 h-5 w-5" />
                <span>Interview communication techniques</span>
              </li>
            </ul>
          </div>

          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4">Course Content</h2>
            <div className="space-y-3">
              {modules.map((module) => (
                <div key={module.id} className="border border-neutral-200 rounded-lg overflow-hidden">
                  <div 
                    className="p-4 bg-neutral-100 flex justify-between items-center cursor-pointer"
                    onClick={() => toggleModule(module.id)}
                  >
                    <div className="flex items-center">
                      <span className="font-medium">{module.title}</span>
                      <span className="ml-2 text-xs px-2 py-0.5 bg-primary/10 text-primary rounded-full">
                        {lessonsMap[module.id]?.length || 0} lessons
                      </span>
                    </div>
                    {expandedModules[module.id] ? (
                      <ChevronUp className="text-neutral-500 h-5 w-5" />
                    ) : (
                      <ChevronDown className="text-neutral-500 h-5 w-5" />
                    )}
                  </div>
                  
                  {expandedModules[module.id] && (
                    <ul className="divide-y divide-neutral-200">
                      {lessonsMap[module.id]?.map((lesson) => (
                        <li key={lesson.id} className="p-4 flex justify-between items-center">
                          <div className="flex items-center">
                            {lesson.videoUrl ? (
                              <PlayCircle className="text-primary mr-3 h-5 w-5" />
                            ) : (
                              <FileText className="text-neutral-500 mr-3 h-5 w-5" />
                            )}
                            <span>{lesson.title}</span>
                          </div>
                          <span className="text-sm text-neutral-500">
                            {lesson.duration} min
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="p-6 lg:border-l border-neutral-200">
          <div className="bg-neutral-100 rounded-lg p-6 mb-6 sticky top-6">
            <div className="text-2xl font-bold mb-4">${course.price.toFixed(2)}</div>
            <Button 
              className="w-full mb-3" 
              onClick={handleEnroll}
            >
              Enroll Now
            </Button>
            <Button 
              className="w-full mb-4" 
              variant="outline"
              onClick={handleAddToWishlist}
            >
              Add to Wishlist
            </Button>
            
            <div className="mb-4">
              <h3 className="font-semibold mb-2">This course includes:</h3>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <Video className="text-neutral-700 mr-2 h-5 w-5" />
                  <span>{formatDuration(course.duration)} of video content</span>
                </li>
                <li className="flex items-center">
                  <File className="text-neutral-700 mr-2 h-5 w-5" />
                  <span>25 downloadable resources</span>
                </li>
                <li className="flex items-center">
                  <Clock className="text-neutral-700 mr-2 h-5 w-5" />
                  <span>Lifetime access</span>
                </li>
                <li className="flex items-center">
                  <Award className="text-neutral-700 mr-2 h-5 w-5" />
                  <span>Certificate of completion</span>
                </li>
                <li className="flex items-center">
                  <Users className="text-neutral-700 mr-2 h-5 w-5" />
                  <span>Access to community forum</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2">Share this course:</h3>
              <div className="flex space-x-3">
                <a href="#" className="text-neutral-700 hover:text-primary">
                  <Linkedin className="h-5 w-5" />
                </a>
                <a href="#" className="text-neutral-700 hover:text-primary">
                  <Twitter className="h-5 w-5" />
                </a>
                <a href="#" className="text-neutral-700 hover:text-primary">
                  <Facebook className="h-5 w-5" />
                </a>
                <a href="#" className="text-neutral-700 hover:text-primary">
                  <Mail className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;
