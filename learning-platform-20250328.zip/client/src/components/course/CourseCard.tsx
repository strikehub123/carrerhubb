import { Link } from "wouter";
import { Clock, Star } from "lucide-react";
import { Course } from "@/lib/types";
import { formatDuration } from "@/lib/utils";

interface CourseCardProps {
  course: Course;
}

const CourseCard = ({ course }: CourseCardProps) => {
  const {
    id,
    title,
    description,
    imageUrl,
    price,
    duration,
    rating,
    difficulty,
    categoryId
  } = course;

  // Truncate description if it's too long
  const truncatedDescription = description.length > 100
    ? `${description.substring(0, 100)}...`
    : description;

  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 course-card">
      <Link href={`/courses/${id}`}>
        <img 
          src={imageUrl} 
          alt={title} 
          className="w-full h-48 object-cover"
        />
        <div className="p-6">
          <div className="flex justify-between items-start mb-2">
            <span className="px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded">
              {difficulty}
            </span>
            <div className="flex items-center">
              <Star className="h-4 w-4 text-[#F59E0B] fill-[#F59E0B]" />
              <span className="ml-1 text-sm font-medium">{rating.toFixed(1)}</span>
            </div>
          </div>
          <h3 className="font-bold text-lg mb-2">{title}</h3>
          <p className="text-neutral-700 text-sm mb-4">{truncatedDescription}</p>
          <div className="flex justify-between items-center">
            <div>
              <span className="text-primary font-bold">${price.toFixed(2)}</span>
            </div>
            <div className="flex items-center space-x-1 text-sm text-neutral-700">
              <Clock className="h-4 w-4" />
              <span>{formatDuration(duration)}</span>
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
};

export default CourseCard;
