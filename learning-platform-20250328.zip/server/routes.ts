import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertCourseSchema, 
  insertModuleSchema, 
  insertLessonSchema,
  insertExamSchema,
  insertQuestionSchema,
  insertOptionSchema,
  insertUserProgressSchema,
  insertExamResultSchema,
  insertCategoryScoreSchema
} from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Error handler for validation errors
  const handleZodError = (error: unknown, res: Response) => {
    if (error instanceof ZodError) {
      return res.status(400).json({
        message: "Invalid data provided",
        errors: error.errors
      });
    }
    console.error("Unexpected error:", error);
    return res.status(500).json({ message: "Internal server error" });
  };

  // User routes
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUserByUsername = await storage.getUserByUsername(userData.username);
      if (existingUserByUsername) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingUserByEmail = await storage.getUserByEmail(userData.email);
      if (existingUserByEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      // Create user
      const user = await storage.createUser(userData);
      
      // Don't return password in response
      const { password, ...userWithoutPassword } = user;
      
      return res.status(201).json(userWithoutPassword);
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ message: "Username and password are required" });
    }
    
    const user = await storage.getUserByUsername(username);
    
    if (!user || user.password !== password) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    
    // Don't return password in response
    const { password: _, ...userWithoutPassword } = user;
    
    return res.status(200).json(userWithoutPassword);
  });
  
  // Category routes
  app.get("/api/categories", async (_req: Request, res: Response) => {
    const categories = await storage.getCategories();
    return res.status(200).json(categories);
  });
  
  app.get("/api/categories/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid category ID" });
    }
    
    const category = await storage.getCategory(id);
    
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }
    
    return res.status(200).json(category);
  });
  
  // Course routes
  app.get("/api/courses", async (_req: Request, res: Response) => {
    const courses = await storage.getCourses();
    return res.status(200).json(courses);
  });
  
  app.get("/api/courses/featured", async (req: Request, res: Response) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 3;
    const featuredCourses = await storage.getFeaturedCourses(limit);
    return res.status(200).json(featuredCourses);
  });
  
  app.get("/api/courses/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid course ID" });
    }
    
    const course = await storage.getCourse(id);
    
    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }
    
    return res.status(200).json(course);
  });
  
  app.get("/api/categories/:id/courses", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid category ID" });
    }
    
    const category = await storage.getCategory(id);
    
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }
    
    const courses = await storage.getCoursesByCategory(id);
    return res.status(200).json(courses);
  });
  
  // Module routes
  app.get("/api/courses/:id/modules", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid course ID" });
    }
    
    const course = await storage.getCourse(id);
    
    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }
    
    const modules = await storage.getModules(id);
    return res.status(200).json(modules);
  });
  
  // Lesson routes
  app.get("/api/modules/:id/lessons", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid module ID" });
    }
    
    const module = await storage.getModule(id);
    
    if (!module) {
      return res.status(404).json({ message: "Module not found" });
    }
    
    const lessons = await storage.getLessons(id);
    return res.status(200).json(lessons);
  });
  
  // Exam routes
  app.get("/api/exams", async (_req: Request, res: Response) => {
    const exams = await storage.getExams();
    return res.status(200).json(exams);
  });
  
  app.get("/api/exams/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid exam ID" });
    }
    
    const exam = await storage.getExam(id);
    
    if (!exam) {
      return res.status(404).json({ message: "Exam not found" });
    }
    
    return res.status(200).json(exam);
  });
  
  app.get("/api/categories/:id/exams", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid category ID" });
    }
    
    const category = await storage.getCategory(id);
    
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }
    
    const exams = await storage.getExamsByCategory(id);
    return res.status(200).json(exams);
  });
  
  // Get available papers for an exam
  app.get("/api/exams/:id/papers", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid exam ID" });
    }
    
    const exam = await storage.getExam(id);
    
    if (!exam) {
      return res.status(404).json({ message: "Exam not found" });
    }
    
    // Get all questions for this exam
    const allQuestions = Array.from(await storage.getAllExamQuestions(id));
    
    // Extract unique paper IDs
    const paperIds = new Set<number>();
    allQuestions.forEach(question => {
      paperIds.add(question.paperId || 0);
    });
    
    // Generate paper objects
    const papers = Array.from(paperIds).map(paperId => ({
      id: paperId,
      name: paperId === 0 ? "Default Paper" : `Practice Paper ${paperId}`,
      questionCount: allQuestions.filter(q => (q.paperId || 0) === paperId).length
    }));
    
    return res.status(200).json(papers);
  });
  
  // Question routes
  app.get("/api/exams/:id/questions", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    const paperId = req.query.paper ? parseInt(req.query.paper as string) : 0;
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid exam ID" });
    }
    
    const exam = await storage.getExam(id);
    
    if (!exam) {
      return res.status(404).json({ message: "Exam not found" });
    }
    
    let questions;
    
    if (paperId > 0) {
      // Get paper-specific questions
      questions = await storage.getQuestionsByPaper(id, paperId);
    } else {
      // Get default questions (first paper)
      questions = await storage.getQuestions(id);
    }
    
    // Get options for each question
    const questionsWithOptions = await Promise.all(
      questions.map(async (question) => {
        const options = await storage.getOptions(question.id);
        return { ...question, options };
      })
    );
    
    return res.status(200).json(questionsWithOptions);
  });
  
  // User progress routes
  app.get("/api/users/:userId/progress", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.userId);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    const progressList = await storage.getUserProgressList(userId);
    
    // Get course details for each progress item
    const progressWithCourses = await Promise.all(
      progressList.map(async (progress) => {
        const course = await storage.getCourse(progress.courseId);
        return { ...progress, course };
      })
    );
    
    return res.status(200).json(progressWithCourses);
  });
  
  app.post("/api/users/:userId/progress", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const progressData = insertUserProgressSchema.parse({
        ...req.body,
        userId
      });
      
      // Check if progress already exists
      const existingProgress = await storage.getUserProgress(userId, progressData.courseId);
      
      if (existingProgress) {
        // Update existing progress
        const updatedProgress = await storage.updateUserProgress(existingProgress.id, {
          completedLessons: progressData.completedLessons
        });
        return res.status(200).json(updatedProgress);
      } else {
        // Create new progress
        const progress = await storage.createUserProgress(progressData);
        return res.status(201).json(progress);
      }
    } catch (error) {
      return handleZodError(error, res);
    }
  });
  
  // Exam results routes
  app.get("/api/users/:userId/exam-results", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.userId);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    const results = await storage.getExamResults(userId);
    
    // Get exam details and category scores for each result
    const resultsWithDetails = await Promise.all(
      results.map(async (result) => {
        const exam = await storage.getExam(result.examId);
        const categoryScores = await storage.getCategoryScores(result.id);
        return { ...result, exam, categoryScores };
      })
    );
    
    return res.status(200).json(resultsWithDetails);
  });
  
  app.get("/api/exam-results/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid result ID" });
    }
    
    const result = await storage.getExamResult(id);
    
    if (!result) {
      return res.status(404).json({ message: "Exam result not found" });
    }
    
    const exam = await storage.getExam(result.examId);
    const categoryScores = await storage.getCategoryScores(result.id);
    
    return res.status(200).json({ ...result, exam, categoryScores });
  });
  
  app.post("/api/users/:userId/exam-results", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const resultData = insertExamResultSchema.parse({
        ...req.body,
        userId
      });
      
      const result = await storage.createExamResult(resultData);
      
      // Create category scores if provided
      if (req.body.categoryScores && Array.isArray(req.body.categoryScores)) {
        for (const scoreData of req.body.categoryScores) {
          await storage.createCategoryScore({
            ...scoreData,
            resultId: result.id
          });
        }
      }
      
      // Get the created category scores
      const categoryScores = await storage.getCategoryScores(result.id);
      
      return res.status(201).json({ ...result, categoryScores });
    } catch (error) {
      return handleZodError(error, res);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
