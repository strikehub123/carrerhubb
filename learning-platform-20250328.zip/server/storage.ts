import {
  users, User, InsertUser,
  categories, Category, InsertCategory,
  courses, Course, InsertCourse,
  modules, Module, InsertModule,
  lessons, Lesson, InsertLesson,
  exams, Exam, InsertExam,
  questions, Question, InsertQuestion,
  options, Option, InsertOption,
  userProgress, UserProgress, InsertUserProgress,
  examResults, ExamResult, InsertExamResult,
  categoryScores, CategoryScore, InsertCategoryScore
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Course operations
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  getCoursesByCategory(categoryId: number): Promise<Course[]>;
  getFeaturedCourses(limit?: number): Promise<Course[]>;
  createCourse(course: InsertCourse): Promise<Course>;
  
  // Module operations
  getModules(courseId: number): Promise<Module[]>;
  getModule(id: number): Promise<Module | undefined>;
  createModule(module: InsertModule): Promise<Module>;
  
  // Lesson operations
  getLessons(moduleId: number): Promise<Lesson[]>;
  getLesson(id: number): Promise<Lesson | undefined>;
  createLesson(lesson: InsertLesson): Promise<Lesson>;
  
  // Exam operations
  getExams(): Promise<Exam[]>;
  getExam(id: number): Promise<Exam | undefined>;
  getExamsByCategory(categoryId: number): Promise<Exam[]>;
  createExam(exam: InsertExam): Promise<Exam>;
  
  // Question operations
  getQuestions(examId: number): Promise<Question[]>;
  getQuestionsByPaper(examId: number, paperId: number): Promise<Question[]>; // Method for paper-specific questions
  getAllExamQuestions(examId: number): Promise<Question[]>; // Method to get all questions for an exam regardless of paper
  getQuestion(id: number): Promise<Question | undefined>;
  createQuestion(question: InsertQuestion): Promise<Question>;
  
  // Option operations
  getOptions(questionId: number): Promise<Option[]>;
  createOption(option: InsertOption): Promise<Option>;
  
  // User progress operations
  getUserProgress(userId: number, courseId: number): Promise<UserProgress | undefined>;
  getUserProgressList(userId: number): Promise<UserProgress[]>;
  createUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  updateUserProgress(id: number, progress: Partial<UserProgress>): Promise<UserProgress>;
  
  // Exam results operations
  getExamResults(userId: number): Promise<ExamResult[]>;
  getExamResult(id: number): Promise<ExamResult | undefined>;
  createExamResult(result: InsertExamResult): Promise<ExamResult>;
  
  // Category scores operations
  getCategoryScores(resultId: number): Promise<CategoryScore[]>;
  createCategoryScore(score: InsertCategoryScore): Promise<CategoryScore>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private courses: Map<number, Course>;
  private modules: Map<number, Module>;
  private lessons: Map<number, Lesson>;
  private exams: Map<number, Exam>;
  private questions: Map<number, Question>;
  private options: Map<number, Option>;
  private userProgress: Map<number, UserProgress>;
  private examResults: Map<number, ExamResult>;
  private categoryScores: Map<number, CategoryScore>;
  
  private userIdCounter: number;
  private categoryIdCounter: number;
  private courseIdCounter: number;
  private moduleIdCounter: number;
  private lessonIdCounter: number;
  private examIdCounter: number;
  private questionIdCounter: number;
  private optionIdCounter: number;
  private userProgressIdCounter: number;
  private examResultIdCounter: number;
  private categoryScoreIdCounter: number;
  
  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.courses = new Map();
    this.modules = new Map();
    this.lessons = new Map();
    this.exams = new Map();
    this.questions = new Map();
    this.options = new Map();
    this.userProgress = new Map();
    this.examResults = new Map();
    this.categoryScores = new Map();
    
    this.userIdCounter = 1;
    this.categoryIdCounter = 1;
    this.courseIdCounter = 1;
    this.moduleIdCounter = 1;
    this.lessonIdCounter = 1;
    this.examIdCounter = 1;
    this.questionIdCounter = 1;
    this.optionIdCounter = 1;
    this.userProgressIdCounter = 1;
    this.examResultIdCounter = 1;
    this.categoryScoreIdCounter = 1;
    
    // Initialize with seed data
    this.initializeData();
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }
  
  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = {
      ...userData,
      id,
      createdAt: now,
      avatarUrl: userData.avatarUrl || null
    };
    this.users.set(id, user);
    return user;
  }
  
  // Category operations
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async createCategory(categoryData: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const category: Category = { 
      ...categoryData, 
      id,
      description: categoryData.description || null,
      courseCount: categoryData.courseCount || 0
    };
    this.categories.set(id, category);
    return category;
  }
  
  // Course operations
  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }
  
  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }
  
  async getCoursesByCategory(categoryId: number): Promise<Course[]> {
    return Array.from(this.courses.values())
      .filter(course => course.categoryId === categoryId);
  }
  
  async getFeaturedCourses(limit: number = 3): Promise<Course[]> {
    return Array.from(this.courses.values())
      .sort((a, b) => {
        const ratingA = a.rating || 0;
        const ratingB = b.rating || 0;
        return ratingB - ratingA;
      })
      .slice(0, limit);
  }
  
  async createCourse(courseData: InsertCourse): Promise<Course> {
    const id = this.courseIdCounter++;
    const now = new Date();
    const course: Course = {
      ...courseData,
      id,
      createdAt: now,
      imageUrl: courseData.imageUrl || null,
      rating: courseData.rating || null,
      ratingCount: courseData.ratingCount || null
    };
    this.courses.set(id, course);
    return course;
  }
  
  // Module operations
  async getModules(courseId: number): Promise<Module[]> {
    return Array.from(this.modules.values())
      .filter(module => module.courseId === courseId)
      .sort((a, b) => a.order - b.order);
  }
  
  async getModule(id: number): Promise<Module | undefined> {
    return this.modules.get(id);
  }
  
  async createModule(moduleData: InsertModule): Promise<Module> {
    const id = this.moduleIdCounter++;
    const module: Module = { 
      ...moduleData, 
      id,
      description: moduleData.description || null
    };
    this.modules.set(id, module);
    return module;
  }
  
  // Lesson operations
  async getLessons(moduleId: number): Promise<Lesson[]> {
    return Array.from(this.lessons.values())
      .filter(lesson => lesson.moduleId === moduleId)
      .sort((a, b) => a.order - b.order);
  }
  
  async getLesson(id: number): Promise<Lesson | undefined> {
    return this.lessons.get(id);
  }
  
  async createLesson(lessonData: InsertLesson): Promise<Lesson> {
    const id = this.lessonIdCounter++;
    const lesson: Lesson = { 
      ...lessonData, 
      id,
      videoUrl: lessonData.videoUrl || null,
      notes: lessonData.notes || null
    };
    this.lessons.set(id, lesson);
    return lesson;
  }
  
  // Exam operations
  async getExams(): Promise<Exam[]> {
    return Array.from(this.exams.values());
  }
  
  async getExam(id: number): Promise<Exam | undefined> {
    return this.exams.get(id);
  }
  
  async getExamsByCategory(categoryId: number): Promise<Exam[]> {
    return Array.from(this.exams.values())
      .filter(exam => exam.categoryId === categoryId);
  }
  
  async createExam(examData: InsertExam): Promise<Exam> {
    const id = this.examIdCounter++;
    const exam: Exam = { 
      ...examData, 
      id,
      successRate: examData.successRate || null
    };
    this.exams.set(id, exam);
    return exam;
  }
  
  // Question operations
  async getQuestions(examId: number): Promise<Question[]> {
    return Array.from(this.questions.values())
      .filter(question => question.examId === examId && (!question.paperId || question.paperId === 0));
  }
  
  async getQuestionsByPaper(examId: number, paperId: number): Promise<Question[]> {
    return Array.from(this.questions.values())
      .filter(question => question.examId === examId && question.paperId === paperId);
  }
  
  async getAllExamQuestions(examId: number): Promise<Question[]> {
    return Array.from(this.questions.values())
      .filter(question => question.examId === examId);
  }
  
  async getQuestion(id: number): Promise<Question | undefined> {
    return this.questions.get(id);
  }
  
  async createQuestion(questionData: InsertQuestion): Promise<Question> {
    const id = this.questionIdCounter++;
    const question: Question = { 
      ...questionData, 
      id,
      code: questionData.code || null,
      paperId: questionData.paperId || 0
    };
    this.questions.set(id, question);
    return question;
  }
  
  // Option operations
  async getOptions(questionId: number): Promise<Option[]> {
    return Array.from(this.options.values())
      .filter(option => option.questionId === questionId);
  }
  
  async createOption(optionData: InsertOption): Promise<Option> {
    const id = this.optionIdCounter++;
    const option: Option = { ...optionData, id };
    this.options.set(id, option);
    return option;
  }
  
  // User progress operations
  async getUserProgress(userId: number, courseId: number): Promise<UserProgress | undefined> {
    return Array.from(this.userProgress.values())
      .find(progress => progress.userId === userId && progress.courseId === courseId);
  }
  
  async getUserProgressList(userId: number): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values())
      .filter(progress => progress.userId === userId);
  }
  
  async createUserProgress(progressData: InsertUserProgress): Promise<UserProgress> {
    const id = this.userProgressIdCounter++;
    const now = new Date();
    const progress: UserProgress = {
      ...progressData,
      id,
      lastAccessedAt: now,
      completedLessons: progressData.completedLessons || 0
    };
    this.userProgress.set(id, progress);
    return progress;
  }
  
  async updateUserProgress(id: number, progressData: Partial<UserProgress>): Promise<UserProgress> {
    const existingProgress = this.userProgress.get(id);
    if (!existingProgress) {
      throw new Error(`User progress with ID ${id} not found`);
    }
    
    const now = new Date();
    const updatedProgress: UserProgress = {
      ...existingProgress,
      ...progressData,
      lastAccessedAt: now
    };
    
    this.userProgress.set(id, updatedProgress);
    return updatedProgress;
  }
  
  // Exam results operations
  async getExamResults(userId: number): Promise<ExamResult[]> {
    return Array.from(this.examResults.values())
      .filter(result => result.userId === userId);
  }
  
  async getExamResult(id: number): Promise<ExamResult | undefined> {
    return this.examResults.get(id);
  }
  
  async createExamResult(resultData: InsertExamResult): Promise<ExamResult> {
    const id = this.examResultIdCounter++;
    const now = new Date();
    const result: ExamResult = {
      ...resultData,
      id,
      completedAt: now
    };
    this.examResults.set(id, result);
    return result;
  }
  
  // Category scores operations
  async getCategoryScores(resultId: number): Promise<CategoryScore[]> {
    return Array.from(this.categoryScores.values())
      .filter(score => score.resultId === resultId);
  }
  
  async createCategoryScore(scoreData: InsertCategoryScore): Promise<CategoryScore> {
    const id = this.categoryScoreIdCounter++;
    const score: CategoryScore = { ...scoreData, id };
    this.categoryScores.set(id, score);
    return score;
  }
  
  // Initialize with sample data
  private initializeData(): void {
    // Create categories
    const softwareEngCategory = this.createSampleCategory({
      name: "Software Engineering",
      description: "Master software development skills and engineering practices",
      icon: "fa-code",
      colorScheme: "primary",
      courseCount: 42
    });
    
    const dataScience = this.createSampleCategory({
      name: "Data Science",
      description: "Learn data analysis, machine learning and statistical methods",
      icon: "fa-database",
      colorScheme: "secondary",
      courseCount: 38
    });
    
    const productManagement = this.createSampleCategory({
      name: "Product Management",
      description: "Master product strategy, development and go-to-market tactics",
      icon: "fa-users-cog",
      colorScheme: "accent",
      courseCount: 29
    });
    
    const uxDesign = this.createSampleCategory({
      name: "UX/UI Design",
      description: "Create beautiful and functional user interfaces and experiences",
      icon: "fa-paint-brush",
      colorScheme: "warning",
      courseCount: 35
    });
    
    // Create courses
    const systemDesignCourse = this.createSampleCourse({
      title: "System Design for Tech Interviews",
      description: "Master the art of designing scalable systems for technical interviews at FAANG companies.",
      imageUrl: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3",
      price: 3999, // ₹3,999 (Converted from USD to INR)
      duration: 720, // 12 hours
      categoryId: softwareEngCategory.id,
      difficulty: "Advanced",
      rating: 4.8,
      ratingCount: 243
    });
    
    const algorithmsCourse = this.createSampleCourse({
      title: "Data Structures & Algorithms Mastery",
      description: "Comprehensive guide to acing coding interviews with practical examples.",
      imageUrl: "https://images.unsplash.com/photo-1507721999472-8ed4421c4af2",
      price: 4499, // ₹4,499 (Converted from USD to INR)
      duration: 1200, // 20 hours
      categoryId: softwareEngCategory.id,
      difficulty: "Intermediate",
      rating: 4.9,
      ratingCount: 187
    });
    
    const pmCourse = this.createSampleCourse({
      title: "Product Management Interview Prep",
      description: "Strategies and frameworks to excel in product management interviews.",
      imageUrl: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40",
      price: 3499, // ₹3,499 (Converted from USD to INR)
      duration: 900, // 15 hours
      categoryId: productManagement.id,
      difficulty: "Beginner",
      rating: 4.7,
      ratingCount: 156
    });
    
    // Create modules for System Design course
    const module1 = this.createSampleModule({
      courseId: systemDesignCourse.id,
      title: "Fundamentals of System Design",
      description: "Learn the core concepts and foundation of system design",
      order: 1
    });
    
    const module2 = this.createSampleModule({
      courseId: systemDesignCourse.id,
      title: "Database Design",
      description: "Explore different database types and their use cases",
      order: 2
    });
    
    const module3 = this.createSampleModule({
      courseId: systemDesignCourse.id,
      title: "Caching Strategies",
      description: "Learn about various caching techniques and when to use them",
      order: 3
    });
    
    // Create lessons for module 1
    this.createSampleLesson({
      moduleId: module1.id,
      title: "Introduction to System Design",
      content: "Overview of system design principles and interview expectations.",
      videoUrl: "https://www.youtube.com/watch?v=xpDnVSmNFX0",
      notes: "Key points: 1) Understand requirements, 2) Start with high-level architecture, 3) Deep dive into components, 4) Discuss trade-offs",
      duration: 15,
      order: 1
    });
    
    this.createSampleLesson({
      moduleId: module1.id,
      title: "Scalability Principles",
      content: "Understanding vertical and horizontal scaling strategies.",
      videoUrl: "https://www.youtube.com/watch?v=K0Ta65OqQkY",
      notes: "Horizontal vs Vertical Scaling:\n- Horizontal: Adding more machines\n- Vertical: Adding more power to existing machines\n\nKey considerations: Cost, maintenance, availability",
      duration: 22,
      order: 2
    });
    
    this.createSampleLesson({
      moduleId: module1.id,
      title: "Performance vs Scalability",
      content: "Differentiating between performance and scalability concerns.",
      videoUrl: "https://www.youtube.com/watch?v=qkj5W98Xdvw",
      notes: "Performance: How fast a system processes a single task\nScalability: How well a system maintains performance as load increases\n\nOptimization strategies:\n1. Caching\n2. Load balancing\n3. Database optimization\n4. Asynchronous processing",
      duration: 18,
      order: 3
    });
    
    // Create exams
    const googleExam = this.createSampleExam({
      title: "Google SWE Interview Simulation",
      description: "Comprehensive test covering algorithms, system design, and behavioral questions.",
      duration: 120, // 2 hours
      questionCount: 60,
      categoryId: softwareEngCategory.id,
      difficulty: "Advanced",
      passPercentage: 65,
      successRate: 32
    });
    
    const dataExam = this.createSampleExam({
      title: "Data Science Technical Assessment",
      description: "Practice exam covering statistics, machine learning algorithms, and SQL challenges.",
      duration: 90, // 1.5 hours
      questionCount: 45,
      categoryId: dataScience.id,
      difficulty: "Intermediate",
      passPercentage: 60,
      successRate: 45
    });
    
    const pmExam = this.createSampleExam({
      title: "Product Manager Case Study Challenge",
      description: "Realistic PM scenarios with analytical, strategic, and execution challenges.",
      duration: 75, // 1.25 hours
      questionCount: 30,
      categoryId: productManagement.id,
      difficulty: "Beginner-Friendly",
      passPercentage: 55,
      successRate: 62
    });
    
    // Create sample question for Google SWE exam
    const question = this.createSampleQuestion({
      examId: googleExam.id,
      question: "You are given an array of integers and a target sum. Write a function that returns true if there is a subset of the array that sums up to the target sum.",
      code: "Input: nums = [3, 34, 4, 12, 5, 2], target = 9\nOutput: true (because 4 + 5 = 9)",
      type: "multiple-choice",
      category: "Algorithms",
      difficulty: "Medium"
    });
    
    // Create options for the question
    this.createSampleOption({
      questionId: question.id,
      text: "Use a greedy algorithm that sorts the array and iteratively picks the largest numbers that don't exceed the target.",
      isCorrect: false
    });
    
    this.createSampleOption({
      questionId: question.id,
      text: "Implement a dynamic programming solution with a 2D boolean array dp[i][j] representing whether a subset of the first i elements can sum to j.",
      isCorrect: true
    });
    
    this.createSampleOption({
      questionId: question.id,
      text: "Use a brute force approach to generate all possible subsets and check their sums.",
      isCorrect: false
    });
    
    this.createSampleOption({
      questionId: question.id,
      text: "Apply a BFS approach using a queue to explore all possible sums that can be generated by including or excluding each element.",
      isCorrect: false
    });
    
    // Create more questions for Google SWE exam (practice test papers - Paper 1)
    
    // Algorithm questions
    const question2 = this.createSampleQuestion({
      examId: googleExam.id,
      question: "What is the time complexity of the quicksort algorithm in the worst case?",
      type: "multiple-choice",
      category: "Algorithms",
      difficulty: "Easy"
    });
    
    this.createSampleOption({ questionId: question2.id, text: "O(n)", isCorrect: false });
    this.createSampleOption({ questionId: question2.id, text: "O(n log n)", isCorrect: false });
    this.createSampleOption({ questionId: question2.id, text: "O(n²)", isCorrect: true });
    this.createSampleOption({ questionId: question2.id, text: "O(log n)", isCorrect: false });
    
    const question3 = this.createSampleQuestion({
      examId: googleExam.id,
      question: "Given a binary tree, implement an algorithm to check if it is a binary search tree.",
      code: "class TreeNode {\n  int val;\n  TreeNode left;\n  TreeNode right;\n}",
      type: "multiple-choice",
      category: "Data Structures",
      difficulty: "Medium"
    });
    
    this.createSampleOption({ 
      questionId: question3.id, 
      text: "Perform an in-order traversal and verify the values are sorted in ascending order.", 
      isCorrect: true 
    });
    this.createSampleOption({ 
      questionId: question3.id, 
      text: "Check if each node's value is greater than all nodes in its left subtree and less than all nodes in its right subtree.", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: question3.id, 
      text: "Perform a level-order traversal and check that each level follows BST properties.", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: question3.id, 
      text: "Calculate the height of left and right subtrees and ensure they differ by at most 1.", 
      isCorrect: false 
    });
    
    // System Design questions
    const question4 = this.createSampleQuestion({
      examId: googleExam.id,
      question: "You are designing a URL shortening service like TinyURL. Describe the high-level system architecture.",
      type: "multiple-choice",
      category: "System Design",
      difficulty: "Hard"
    });
    
    this.createSampleOption({ 
      questionId: question4.id, 
      text: "Use a hash function to convert the original URL to a short key, store the mapping in a database, and implement a web server to redirect short URLs to original URLs.", 
      isCorrect: true 
    });
    this.createSampleOption({ 
      questionId: question4.id, 
      text: "Implement a content delivery network (CDN) that caches original URLs and assigns sequential IDs to each URL.", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: question4.id, 
      text: "Use a distributed file system to store original URLs as files, with the filename being the shortened version.", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: question4.id, 
      text: "Implement a peer-to-peer network where each node stores a portion of the URL mappings based on a consistent hashing algorithm.", 
      isCorrect: false 
    });
    
    // Data Science exam questions
    const dsQuestion1 = this.createSampleQuestion({
      examId: dataExam.id,
      question: "Which of the following is NOT a regression algorithm?",
      type: "multiple-choice",
      category: "Machine Learning",
      difficulty: "Medium"
    });
    
    this.createSampleOption({ questionId: dsQuestion1.id, text: "Linear Regression", isCorrect: false });
    this.createSampleOption({ questionId: dsQuestion1.id, text: "Logistic Regression", isCorrect: false });
    this.createSampleOption({ questionId: dsQuestion1.id, text: "K-means Clustering", isCorrect: true });
    this.createSampleOption({ questionId: dsQuestion1.id, text: "Ridge Regression", isCorrect: false });
    
    const dsQuestion2 = this.createSampleQuestion({
      examId: dataExam.id,
      question: "What is the purpose of the 'train_test_split' function in scikit-learn?",
      type: "multiple-choice",
      category: "Python Libraries",
      difficulty: "Easy"
    });
    
    this.createSampleOption({ 
      questionId: dsQuestion2.id, 
      text: "To split your dataset into training and testing sets to evaluate model performance", 
      isCorrect: true 
    });
    this.createSampleOption({ 
      questionId: dsQuestion2.id, 
      text: "To split your model into parallel training processes for faster execution", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: dsQuestion2.id, 
      text: "To split your features into categorical and numerical variables", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: dsQuestion2.id, 
      text: "To split your dataset by specific date ranges for time-series analysis", 
      isCorrect: false 
    });
    
    // Create Google SWE Paper 2 (Advanced) questions
    // Paper 2 - Algorithm questions
    const paperTwoQ1 = this.createSampleQuestion({
      examId: googleExam.id,
      paperId: 2,
      question: "What is the worst-case time complexity for finding an element in a balanced binary search tree?",
      type: "multiple-choice",
      category: "Algorithms",
      difficulty: "Medium"
    });
    
    this.createSampleOption({ questionId: paperTwoQ1.id, text: "O(1)", isCorrect: false });
    this.createSampleOption({ questionId: paperTwoQ1.id, text: "O(log n)", isCorrect: true });
    this.createSampleOption({ questionId: paperTwoQ1.id, text: "O(n)", isCorrect: false });
    this.createSampleOption({ questionId: paperTwoQ1.id, text: "O(n log n)", isCorrect: false });
    
    const paperTwoQ2 = this.createSampleQuestion({
      examId: googleExam.id,
      paperId: 2,
      question: "Which of the following algorithms would be most efficient for finding the shortest path in a weighted graph with negative edge weights?",
      type: "multiple-choice",
      category: "Algorithms",
      difficulty: "Hard"
    });
    
    this.createSampleOption({ questionId: paperTwoQ2.id, text: "Dijkstra's algorithm", isCorrect: false });
    this.createSampleOption({ questionId: paperTwoQ2.id, text: "Breadth-First Search", isCorrect: false });
    this.createSampleOption({ questionId: paperTwoQ2.id, text: "Bellman-Ford algorithm", isCorrect: true });
    this.createSampleOption({ questionId: paperTwoQ2.id, text: "A* search algorithm", isCorrect: false });
    
    // Paper 2 - System Design questions
    const paperTwoQ3 = this.createSampleQuestion({
      examId: googleExam.id,
      paperId: 2,
      question: "You are designing a distributed database system. Which of the following consistency models provides the strongest guarantees?",
      type: "multiple-choice",
      category: "System Design",
      difficulty: "Hard"
    });
    
    this.createSampleOption({ questionId: paperTwoQ3.id, text: "Eventual Consistency", isCorrect: false });
    this.createSampleOption({ questionId: paperTwoQ3.id, text: "Strong Consistency", isCorrect: true });
    this.createSampleOption({ questionId: paperTwoQ3.id, text: "Causal Consistency", isCorrect: false });
    this.createSampleOption({ questionId: paperTwoQ3.id, text: "Read-your-writes Consistency", isCorrect: false });
    
    const paperTwoQ4 = this.createSampleQuestion({
      examId: googleExam.id,
      paperId: 2,
      question: "When designing a real-time messaging system that needs to handle millions of concurrent users, which of the following technologies would be most suitable?",
      type: "multiple-choice",
      category: "System Design",
      difficulty: "Advanced"
    });
    
    this.createSampleOption({ questionId: paperTwoQ4.id, text: "REST API with HTTP long polling", isCorrect: false });
    this.createSampleOption({ questionId: paperTwoQ4.id, text: "WebSockets with a distributed message broker", isCorrect: true });
    this.createSampleOption({ questionId: paperTwoQ4.id, text: "GraphQL subscriptions without scaling considerations", isCorrect: false });
    this.createSampleOption({ questionId: paperTwoQ4.id, text: "SOAP services with regular polling", isCorrect: false });
    
    // Product Management exam questions
    const pmQuestion1 = this.createSampleQuestion({
      examId: pmExam.id,
      question: "Which product prioritization framework uses a 2x2 grid with impact and effort as axes?",
      type: "multiple-choice",
      category: "Product Strategy",
      difficulty: "Medium"
    });
    
    this.createSampleOption({ questionId: pmQuestion1.id, text: "RICE", isCorrect: false });
    this.createSampleOption({ questionId: pmQuestion1.id, text: "MoSCoW", isCorrect: false });
    this.createSampleOption({ questionId: pmQuestion1.id, text: "Impact/Effort Matrix", isCorrect: true });
    this.createSampleOption({ questionId: pmQuestion1.id, text: "Kano Model", isCorrect: false });
    
    const pmQuestion2 = this.createSampleQuestion({
      examId: pmExam.id,
      question: "What is the main goal of conducting user interviews during product development?",
      type: "multiple-choice",
      category: "User Research",
      difficulty: "Easy"
    });
    
    this.createSampleOption({ 
      questionId: pmQuestion2.id, 
      text: "To validate your product ideas and understand user needs", 
      isCorrect: true 
    });
    this.createSampleOption({ 
      questionId: pmQuestion2.id, 
      text: "To create detailed product specifications for developers", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: pmQuestion2.id, 
      text: "To identify the most profitable market segments", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: pmQuestion2.id, 
      text: "To determine the optimal pricing strategy for the product", 
      isCorrect: false 
    });
    
    // Create Google SWE Exam Paper 2 (second practice test paper)
    
    // Paper 2 - Coding questions
    const swePaper2Q1 = this.createSampleQuestion({
      examId: googleExam.id,
      question: "What is the time complexity of finding an element in a balanced binary search tree?",
      type: "multiple-choice",
      category: "Data Structures",
      difficulty: "Easy"
    });
    
    this.createSampleOption({ questionId: swePaper2Q1.id, text: "O(n)", isCorrect: false });
    this.createSampleOption({ questionId: swePaper2Q1.id, text: "O(log n)", isCorrect: true });
    this.createSampleOption({ questionId: swePaper2Q1.id, text: "O(n log n)", isCorrect: false });
    this.createSampleOption({ questionId: swePaper2Q1.id, text: "O(1)", isCorrect: false });
    
    const swePaper2Q2 = this.createSampleQuestion({
      examId: googleExam.id,
      question: "Which sorting algorithm is typically used in the implementation of Arrays.sort() in Java for primitive types?",
      type: "multiple-choice",
      category: "Algorithms",
      difficulty: "Medium"
    });
    
    this.createSampleOption({ questionId: swePaper2Q2.id, text: "Quicksort", isCorrect: false });
    this.createSampleOption({ questionId: swePaper2Q2.id, text: "Mergesort", isCorrect: false });
    this.createSampleOption({ questionId: swePaper2Q2.id, text: "Dual-Pivot Quicksort", isCorrect: true });
    this.createSampleOption({ questionId: swePaper2Q2.id, text: "Heapsort", isCorrect: false });
    
    const swePaper2Q3 = this.createSampleQuestion({
      examId: googleExam.id,
      question: "Given two sorted arrays of size m and n respectively, what is the time complexity of merging them into a single sorted array?",
      type: "multiple-choice",
      category: "Algorithms",
      difficulty: "Easy"
    });
    
    this.createSampleOption({ questionId: swePaper2Q3.id, text: "O(m + n)", isCorrect: true });
    this.createSampleOption({ questionId: swePaper2Q3.id, text: "O(m * n)", isCorrect: false });
    this.createSampleOption({ questionId: swePaper2Q3.id, text: "O(log(m + n))", isCorrect: false });
    this.createSampleOption({ questionId: swePaper2Q3.id, text: "O((m + n) log(m + n))", isCorrect: false });
    
    // Paper 2 - System Design questions
    const swePaper2Q4 = this.createSampleQuestion({
      examId: googleExam.id,
      question: "Which pattern would be most appropriate for implementing a notification system that needs to notify multiple subscribers when events occur?",
      type: "multiple-choice",
      category: "System Design",
      difficulty: "Medium"
    });
    
    this.createSampleOption({ questionId: swePaper2Q4.id, text: "Observer Pattern", isCorrect: true });
    this.createSampleOption({ questionId: swePaper2Q4.id, text: "Singleton Pattern", isCorrect: false });
    this.createSampleOption({ questionId: swePaper2Q4.id, text: "Factory Pattern", isCorrect: false });
    this.createSampleOption({ questionId: swePaper2Q4.id, text: "Adapter Pattern", isCorrect: false });
    
    const swePaper2Q5 = this.createSampleQuestion({
      examId: googleExam.id,
      question: "When designing a distributed cache for a web application, which of the following would be the BEST approach to handle cache invalidation?",
      code: null,
      type: "multiple-choice",
      category: "System Design",
      difficulty: "Hard"
    });
    
    this.createSampleOption({ 
      questionId: swePaper2Q5.id, 
      text: "Use a time-based expiration policy combined with event-based invalidation for critical updates", 
      isCorrect: true 
    });
    this.createSampleOption({ 
      questionId: swePaper2Q5.id, 
      text: "Implement a write-through cache where all writes to the database also update the cache", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: swePaper2Q5.id, 
      text: "Use purely time-based expiration with short TTL values to ensure data freshness", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: swePaper2Q5.id, 
      text: "Implement a read-through cache and never explicitly invalidate entries", 
      isCorrect: false 
    });
    
    // Create Data Science Exam Paper 2
    const dsPaper2Q1 = this.createSampleQuestion({
      examId: dataExam.id,
      question: "What is the main purpose of Principal Component Analysis (PCA)?",
      type: "multiple-choice",
      category: "Machine Learning",
      difficulty: "Medium"
    });
    
    this.createSampleOption({ 
      questionId: dsPaper2Q1.id, 
      text: "Dimensionality reduction while preserving as much variance as possible", 
      isCorrect: true 
    });
    this.createSampleOption({ 
      questionId: dsPaper2Q1.id, 
      text: "Classification of data points into predefined categories", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: dsPaper2Q1.id, 
      text: "Feature selection by identifying the least important variables", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: dsPaper2Q1.id, 
      text: "Regression analysis to predict continuous outcome variables", 
      isCorrect: false 
    });
    
    const dsPaper2Q2 = this.createSampleQuestion({
      examId: dataExam.id,
      question: "Which SQL clause is used to filter groups in a GROUP BY query?",
      type: "multiple-choice",
      category: "SQL",
      difficulty: "Easy"
    });
    
    this.createSampleOption({ questionId: dsPaper2Q2.id, text: "WHERE", isCorrect: false });
    this.createSampleOption({ questionId: dsPaper2Q2.id, text: "HAVING", isCorrect: true });
    this.createSampleOption({ questionId: dsPaper2Q2.id, text: "FILTER", isCorrect: false });
    this.createSampleOption({ questionId: dsPaper2Q2.id, text: "GROUP FILTER", isCorrect: false });
    
    // Create Product Management Exam Paper 2
    const pmPaper2Q1 = this.createSampleQuestion({
      examId: pmExam.id,
      question: "What is the primary purpose of an A/B test in product development?",
      type: "multiple-choice",
      category: "Product Analytics",
      difficulty: "Medium"
    });
    
    this.createSampleOption({ 
      questionId: pmPaper2Q1.id, 
      text: "To compare two versions of a product feature to determine which performs better with users", 
      isCorrect: true 
    });
    this.createSampleOption({ 
      questionId: pmPaper2Q1.id, 
      text: "To test a product with two different user segments (segment A and segment B)", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: pmPaper2Q1.id, 
      text: "To compare the performance of two different products in your portfolio", 
      isCorrect: false 
    });
    this.createSampleOption({ 
      questionId: pmPaper2Q1.id, 
      text: "To test a product in two different markets before full launch", 
      isCorrect: false 
    });
    
    const pmPaper2Q2 = this.createSampleQuestion({
      examId: pmExam.id,
      question: "Which of the following metrics is most appropriate for measuring user engagement?",
      type: "multiple-choice",
      category: "Product Metrics",
      difficulty: "Easy"
    });
    
    this.createSampleOption({ questionId: pmPaper2Q2.id, text: "Daily Active Users (DAU)", isCorrect: true });
    this.createSampleOption({ questionId: pmPaper2Q2.id, text: "Conversion Rate", isCorrect: false });
    this.createSampleOption({ questionId: pmPaper2Q2.id, text: "Customer Acquisition Cost (CAC)", isCorrect: false });
    this.createSampleOption({ questionId: pmPaper2Q2.id, text: "Gross Margin", isCorrect: false });

    // Create users
    this.createSampleUser({
      username: "johndoe",
      password: "password123",
      email: "john.doe@example.com",
      fullName: "John Doe",
      avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e"
    });
  }
  
  private createSampleCategory(data: InsertCategory): Category {
    const id = this.categoryIdCounter++;
    const category: Category = { 
      ...data, 
      id,
      description: data.description || null,
      courseCount: data.courseCount || 0
    };
    this.categories.set(id, category);
    return category;
  }
  
  private createSampleCourse(data: InsertCourse): Course {
    const id = this.courseIdCounter++;
    const now = new Date();
    const course: Course = { 
      ...data, 
      id, 
      createdAt: now,
      imageUrl: data.imageUrl || null,
      rating: data.rating || null,
      ratingCount: data.ratingCount || null
    };
    this.courses.set(id, course);
    return course;
  }
  
  private createSampleModule(data: InsertModule): Module {
    const id = this.moduleIdCounter++;
    const module: Module = { 
      ...data, 
      id,
      description: data.description || null
    };
    this.modules.set(id, module);
    return module;
  }
  
  private createSampleLesson(data: InsertLesson): Lesson {
    const id = this.lessonIdCounter++;
    const lesson: Lesson = { 
      ...data, 
      id,
      videoUrl: data.videoUrl || null,
      notes: data.notes || null
    };
    this.lessons.set(id, lesson);
    return lesson;
  }
  
  private createSampleExam(data: InsertExam): Exam {
    const id = this.examIdCounter++;
    const exam: Exam = { 
      ...data, 
      id,
      successRate: data.successRate || null
    };
    this.exams.set(id, exam);
    return exam;
  }
  
  private createSampleQuestion(data: InsertQuestion): Question {
    const id = this.questionIdCounter++;
    const question: Question = { 
      ...data, 
      id,
      code: data.code || null,
      paperId: data.paperId || 0
    };
    this.questions.set(id, question);
    return question;
  }
  
  private createSampleOption(data: InsertOption): Option {
    const id = this.optionIdCounter++;
    const option: Option = { ...data, id };
    this.options.set(id, option);
    return option;
  }
  
  private createSampleUser(data: InsertUser): User {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...data, 
      id, 
      createdAt: now,
      avatarUrl: data.avatarUrl || null
    };
    this.users.set(id, user);
    return user;
  }
}

export const storage = new MemStorage();
