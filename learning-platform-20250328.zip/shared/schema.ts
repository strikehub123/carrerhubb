import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  avatarUrl: text("avatar_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  fullName: true,
  avatarUrl: true,
});

// Course categories table
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  icon: text("icon").notNull(),
  colorScheme: text("color_scheme").notNull(),
  courseCount: integer("course_count").default(0).notNull(),
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  name: true,
  description: true,
  icon: true,
  colorScheme: true,
  courseCount: true,
});

// Courses table
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  price: doublePrecision("price").notNull(),
  duration: integer("duration").notNull(), // in minutes
  categoryId: integer("category_id").notNull(),
  difficulty: text("difficulty").notNull(),
  rating: doublePrecision("rating").default(0),
  ratingCount: integer("rating_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCourseSchema = createInsertSchema(courses).pick({
  title: true,
  description: true,
  imageUrl: true,
  price: true,
  duration: true,
  categoryId: true,
  difficulty: true,
  rating: true,
  ratingCount: true,
});

// Course modules table
export const modules = pgTable("modules", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  order: integer("order").notNull(),
});

export const insertModuleSchema = createInsertSchema(modules).pick({
  courseId: true,
  title: true,
  description: true,
  order: true,
});

// Lessons table
export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  moduleId: integer("module_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  videoUrl: text("video_url"),
  notes: text("notes"),
  duration: integer("duration").notNull(), // in minutes
  order: integer("order").notNull(),
});

export const insertLessonSchema = createInsertSchema(lessons).pick({
  moduleId: true,
  title: true,
  content: true,
  videoUrl: true,
  notes: true,
  duration: true,
  order: true,
});

// Exams table
export const exams = pgTable("exams", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  duration: integer("duration").notNull(), // in minutes
  questionCount: integer("question_count").notNull(),
  categoryId: integer("category_id").notNull(),
  difficulty: text("difficulty").notNull(),
  passPercentage: integer("pass_percentage").notNull(),
  successRate: integer("success_rate").default(0),
});

export const insertExamSchema = createInsertSchema(exams).pick({
  title: true,
  description: true,
  duration: true,
  questionCount: true,
  categoryId: true,
  difficulty: true,
  passPercentage: true,
  successRate: true,
});

// Questions table
export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  examId: integer("exam_id").notNull(),
  paperId: integer("paper_id").default(0), // Added for multiple practice papers
  question: text("question").notNull(),
  code: text("code"),
  type: text("type").notNull(), // multiple-choice, coding, etc.
  category: text("category").notNull(), // algorithm, system design, etc.
  difficulty: text("difficulty").notNull(),
});

export const insertQuestionSchema = createInsertSchema(questions).pick({
  examId: true,
  paperId: true,
  question: true,
  code: true,
  type: true,
  category: true,
  difficulty: true,
});

// Options table (for multiple choice questions)
export const options = pgTable("options", {
  id: serial("id").primaryKey(),
  questionId: integer("question_id").notNull(),
  text: text("text").notNull(),
  isCorrect: boolean("is_correct").notNull(),
});

export const insertOptionSchema = createInsertSchema(options).pick({
  questionId: true,
  text: true,
  isCorrect: true,
});

// User progress table
export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  courseId: integer("course_id").notNull(),
  completedLessons: integer("completed_lessons").default(0).notNull(),
  totalLessons: integer("total_lessons").notNull(),
  lastAccessedAt: timestamp("last_accessed_at").defaultNow().notNull(),
});

export const insertUserProgressSchema = createInsertSchema(userProgress).pick({
  userId: true,
  courseId: true,
  completedLessons: true,
  totalLessons: true,
  lastAccessedAt: true,
});

// Exam results table
export const examResults = pgTable("exam_results", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  examId: integer("exam_id").notNull(),
  score: integer("score").notNull(),
  maxScore: integer("max_score").notNull(),
  passed: boolean("passed").notNull(),
  timeSpent: integer("time_spent").notNull(), // in seconds
  completedAt: timestamp("completed_at").defaultNow().notNull(),
});

export const insertExamResultSchema = createInsertSchema(examResults).pick({
  userId: true,
  examId: true,
  score: true,
  maxScore: true,
  passed: true,
  timeSpent: true,
});

// Category statistics (for result breakdown)
export const categoryScores = pgTable("category_scores", {
  id: serial("id").primaryKey(),
  resultId: integer("result_id").notNull(),
  category: text("category").notNull(),
  score: integer("score").notNull(),
  maxScore: integer("max_score").notNull(),
  percentage: integer("percentage").notNull(),
});

export const insertCategoryScoreSchema = createInsertSchema(categoryScores).pick({
  resultId: true,
  category: true,
  score: true,
  maxScore: true,
  percentage: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;

export type Course = typeof courses.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;

export type Module = typeof modules.$inferSelect;
export type InsertModule = z.infer<typeof insertModuleSchema>;

export type Lesson = typeof lessons.$inferSelect;
export type InsertLesson = z.infer<typeof insertLessonSchema>;

export type Exam = typeof exams.$inferSelect;
export type InsertExam = z.infer<typeof insertExamSchema>;

export type Question = typeof questions.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;

export type Option = typeof options.$inferSelect;
export type InsertOption = z.infer<typeof insertOptionSchema>;

export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;

export type ExamResult = typeof examResults.$inferSelect;
export type InsertExamResult = z.infer<typeof insertExamResultSchema>;

export type CategoryScore = typeof categoryScores.$inferSelect;
export type InsertCategoryScore = z.infer<typeof insertCategoryScoreSchema>;
