# Learning Platform & Exam Preparation Portal

A full-stack web platform for courses and online exams to help users prepare for job placements.

## Features

- Subject-wise video courses with YouTube integration
- Multiple online exams with practice test papers
- Interview preparation resources
- User profiles and progress tracking
- Course purchase functionality
- Indian rupee pricing for local market
- Dream company profiles and placement preparation

## Technology Stack

- **Frontend**: React, TailwindCSS, Shadcn UI
- **Backend**: Node.js, Express
- **Database**: In-memory storage (can be extended to PostgreSQL)
- **API**: RESTful endpoints
- **Authentication**: Custom auth system

## Installation

1. Clone this repository:
```
git clone <repository-url>
cd learning-platform
```

2. Install dependencies:
```
npm install
```

3. Start the development server:
```
npm run dev
```

4. Open your browser and navigate to:
```
http://localhost:3000
```

## Project Structure

- `/client`: Frontend React application
  - `/src`: Source code
    - `/components`: Reusable UI components
    - `/hooks`: Custom React hooks
    - `/lib`: Utility functions and configs
    - `/pages`: Application pages
- `/server`: Backend Express server
  - `index.ts`: Server entry point
  - `routes.ts`: API routes
  - `storage.ts`: Data storage implementation
  - `vite.ts`: Development server configuration
- `/shared`: Shared types and schemas
  - `schema.ts`: Database schema definitions and types

## API Endpoints

- Authentication:
  - POST `/api/auth/register`: Register a new user
  - POST `/api/auth/login`: Log in a user

- Courses:
  - GET `/api/courses`: Get all courses
  - GET `/api/courses/:id`: Get a specific course
  - GET `/api/courses/featured`: Get featured courses

- Categories:
  - GET `/api/categories`: Get all categories
  - GET `/api/categories/:id`: Get a specific category

- Exams:
  - GET `/api/exams`: Get all exams
  - GET `/api/exams/:id`: Get a specific exam
  - GET `/api/exams/:id/papers`: Get available papers for an exam
  - GET `/api/exams/:id/questions`: Get questions for an exam (use ?paper=X for specific paper)

- User Progress & Results:
  - GET `/api/users/:userId/progress`: Get user's course progress
  - POST `/api/users/:userId/progress`: Update user's course progress
  - GET `/api/users/:userId/exam-results`: Get user's exam results
  - POST `/api/users/:userId/exam-results`: Save a new exam result

## Running in Production

To build for production:

```bash
npm run build
```

Then deploy the generated files to your web server.

## License

This project is licensed under the MIT License - see the LICENSE file for details.